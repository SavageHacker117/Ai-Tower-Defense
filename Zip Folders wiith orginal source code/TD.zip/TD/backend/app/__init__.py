# In app/__init__.py

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO
import os

db = SQLAlchemy()
socketio = SocketIO()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key'

    # --- AWS RDS Database Configuration ---
    # Replace these values with your actual RDS information
    db_user = 'admin'  # The master username you created
    db_password = 'Deatherage17341!' # The master password you created
    db_host = 'tower-defence-db.cz8siwkgchvi.us-east-2.rds.amazonaws.com' # The Endpoint from the RDS console
    db_name = 'tower-defense-db' # The database name (you can often leave this blank if the DB was auto-created, or set it to 'mysql')

    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+mysqlconnector://{db_user}:{db_password}@{db_host}/{db_name}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*")

    with app.app_context():
        from . import models
        from . import events
        from .routes import api_bp
        app.register_blueprint(api_bp)
        db.create_all() # This will create the tables in your new AWS database

    return app