from flask_socketio import emit, join_room, leave_room
from flask import request
from . import socketio

@socketio.on('connect')
def handle_connect():
    sid = request.sid
    print(f'Client connected: {sid}')
    join_room('game_room_1')
    emit('response', {'data': f'Connected and joined room_1'})

@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    print(f'Client disconnected: {sid}')
    leave_room('game_room_1')

@socketio.on('build_tower_request')
def handle_build_tower(data):
    sid = request.sid
    print(f"Received build_tower_request from {sid}: {data}")
    emit('tower_placed', data, to='game_room_1')