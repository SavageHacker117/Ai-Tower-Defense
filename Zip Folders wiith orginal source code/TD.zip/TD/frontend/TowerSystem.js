/**
 * TowerSystem.js
 * Manages tower placement, upgrades, behavior, and combat mechanics
 * for the tower defense game
 * 
 * Refactored to use ES6 modules and dependency injection
 */

export class TowerSystem {
    constructor({ gameMap, healthSystem, targetingSystem, notificationManager, resourceManager }) {
        // Inject only the specific dependencies we need
        this.gameMap = gameMap;
        this.healthSystem = healthSystem;
        this.targetingSystem = targetingSystem;
        this.notificationManager = notificationManager;
        this.resourceManager = resourceManager;
        
        this.towers = new Map(); // towerId -> towerData
        this.towerTypes = new Map(); // towerType -> towerConfig
        this.placementGrid = new Map(); // gridKey -> towerId
        this.eventListeners = new Map();
        
        this.nextTowerId = 1;
        this.gridSize = 32; // Size of each grid cell
        
        this.initializeTowerTypes();
    }

    /**
     * Initialize available tower types and their configurations
     */
    initializeTowerTypes() {
        const towerConfigs = {
            basic: {
                name: 'Basic Tower',
                cost: 100,
                damage: 25,
                range: 80,
                attackSpeed: 1.0, // attacks per second
                projectileSpeed: 300,
                projectileType: 'bullet',
                upgrades: ['cannon', 'rapid'],
                maxLevel: 3,
                description: 'A simple tower with balanced stats',
                sprite: 'tower_basic',
                buildTime: 1000, // ms
                sellValue: 0.7 // 70% of total investment
            },
            cannon: {
                name: 'Cannon Tower',
                cost: 200,
                damage: 80,
                range: 100,
                attackSpeed: 0.5,
                projectileSpeed: 250,
                projectileType: 'cannonball',
                splashRadius: 40,
                splashDamage: 0.5,
                upgrades: ['artillery'],
                maxLevel: 3,
                description: 'High damage with splash effect',
                sprite: 'tower_cannon',
                buildTime: 2000,
                sellValue: 0.7
            },
            laser: {
                name: 'Laser Tower',
                cost: 300,
                damage: 40,
                range: 120,
                attackSpeed: 2.0,
                projectileSpeed: 1000,
                projectileType: 'laser',
                armorPiercing: true,
                upgrades: ['plasma'],
                maxLevel: 3,
                description: 'Fast attacks that pierce armor',
                sprite: 'tower_laser',
                buildTime: 2500,
                sellValue: 0.7
            },
            ice: {
                name: 'Ice Tower',
                cost: 250,
                damage: 20,
                range: 90,
                attackSpeed: 1.2,
                projectileSpeed: 200,
                projectileType: 'ice',
                slowEffect: {
                    duration: 3000,
                    slowAmount: 0.5
                },
                upgrades: ['freeze'],
                maxLevel: 3,
                description: 'Slows enemies with ice attacks',
                sprite: 'tower_ice',
                buildTime: 2000,
                sellValue: 0.7
            },
            poison: {
                name: 'Poison Tower',
                cost: 350,
                damage: 15,
                range: 85,
                attackSpeed: 1.5,
                projectileSpeed: 180,
                projectileType: 'poison',
                poisonEffect: {
                    duration: 5000,
                    damagePerSecond: 10
                },
                upgrades: ['toxic'],
                maxLevel: 3,
                description: 'Deals damage over time with poison',
                sprite: 'tower_poison',
                buildTime: 3000,
                sellValue: 0.7
            },
            lightning: {
                name: 'Lightning Tower',
                cost: 500,
                damage: 60,
                range: 110,
                attackSpeed: 0.8,
                projectileSpeed: 800,
                projectileType: 'lightning',
                chainLightning: {
                    maxTargets: 3,
                    damageReduction: 0.3
                },
                upgrades: ['storm'],
                maxLevel: 3,
                description: 'Chains lightning between enemies',
                sprite: 'tower_lightning',
                buildTime: 4000,
                sellValue: 0.7
            }
        };

        Object.entries(towerConfigs).forEach(([type, config]) => {
            this.towerTypes.set(type, config);
        });
    }

    /**
     * Check if a position is valid for tower placement
     * @param {number} x 
     * @param {number} y 
     * @returns {Object} Validation result
     */
    canPlaceTower(x, y) {
        const gridX = Math.floor(x / this.gridSize);
        const gridY = Math.floor(y / this.gridSize);
        const gridKey = `${gridX},${gridY}`;

        // Check if position is already occupied
        if (this.placementGrid.has(gridKey)) {
            return {
                valid: false,
                reason: 'Position already occupied'
            };
        }

        // Check if position is on the path
        if (this.gameMap && this.gameMap.isOnPath(x, y)) {
            return {
                valid: false,
                reason: 'Cannot place on enemy path'
            };
        }

        // Check if position is within map bounds
        if (this.gameMap && !this.gameMap.isWithinBounds(x, y)) {
            return {
                valid: false,
                reason: 'Position outside map bounds'
            };
        }

        return {
            valid: true,
            gridX,
            gridY,
            gridKey
        };
    }

    /**
     * Place a new tower
     * @param {string} towerType 
     * @param {number} x 
     * @param {number} y 
     * @param {string} playerId 
     * @returns {Object} Placement result
     */
    placeTower(towerType, x, y, playerId = null) {
        const towerConfig = this.towerTypes.get(towerType);
        if (!towerConfig) {
            return {
                success: false,
                reason: 'Invalid tower type'
            };
        }

        // Check if player has enough resources
        if (this.resourceManager && !this.resourceManager.canAfford(towerConfig.cost)) {
            return {
                success: false,
                reason: 'Insufficient resources'
            };
        }

        const placement = this.canPlaceTower(x, y);
        if (!placement.valid) {
            return {
                success: false,
                reason: placement.reason
            };
        }

        // Deduct resources
        if (this.resourceManager) {
            this.resourceManager.spendResources(towerConfig.cost);
        }

        const towerId = `tower_${this.nextTowerId++}`;
        const snapX = placement.gridX * this.gridSize + this.gridSize / 2;
        const snapY = placement.gridY * this.gridSize + this.gridSize / 2;

        const tower = {
            id: towerId,
            type: towerType,
            x: snapX,
            y: snapY,
            level: 1,
            playerId,
            
            // Combat stats
            damage: towerConfig.damage,
            range: towerConfig.range,
            attackSpeed: towerConfig.attackSpeed,
            projectileSpeed: towerConfig.projectileSpeed,
            projectileType: towerConfig.projectileType,
            
            // Special abilities
            splashRadius: towerConfig.splashRadius || 0,
            splashDamage: towerConfig.splashDamage || 0,
            armorPiercing: towerConfig.armorPiercing || false,
            slowEffect: towerConfig.slowEffect || null,
            poisonEffect: towerConfig.poisonEffect || null,
            chainLightning: towerConfig.chainLightning || null,
            
            // State
            lastAttackTime: 0,
            currentTarget: null,
            kills: 0,
            totalDamageDealt: 0,
            
            // Building
            buildStartTime: Date.now(),
            buildTime: towerConfig.buildTime,
            isBuilding: true,
            
            // Economics
            totalCost: towerConfig.cost,
            sellValue: Math.floor(towerConfig.cost * towerConfig.sellValue),
            
            // Upgrades
            availableUpgrades: [...towerConfig.upgrades],
            maxLevel: towerConfig.maxLevel
        };

        // Store tower
        this.towers.set(towerId, tower);
        this.placementGrid.set(placement.gridKey, towerId);

        // Register with health system if needed
        if (this.healthSystem) {
            this.healthSystem.registerEntity(towerId, {
                maxHealth: 100,
                currentHealth: 100,
                entityType: 'tower'
            });
        }

        // Show notification
        if (this.notificationManager) {
            this.notificationManager.showMessage(`${towerConfig.name} placed!`, 'success');
        }

        this.triggerEvent('towerPlaced', {
            tower,
            playerId,
            cost: towerConfig.cost
        });

        // Start build timer
        setTimeout(() => {
            if (this.towers.has(towerId)) {
                tower.isBuilding = false;
                this.triggerEvent('towerBuilt', { tower });
                
                if (this.notificationManager) {
                    this.notificationManager.showMessage(`${towerConfig.name} construction completed!`, 'info');
                }
            }
        }, towerConfig.buildTime);

        return {
            success: true,
            tower,
            cost: towerConfig.cost
        };
    }

    /**
     * Upgrade a tower
     * @param {string} towerId 
     * @param {string} upgradeType 
     * @returns {Object} Upgrade result
     */
    upgradeTower(towerId, upgradeType = 'level') {
        const tower = this.towers.get(towerId);
        if (!tower) {
            return {
                success: false,
                reason: 'Tower not found'
            };
        }

        if (tower.isBuilding) {
            return {
                success: false,
                reason: 'Tower is still building'
            };
        }

        if (upgradeType === 'level') {
            return this.upgradeTowerLevel(tower);
        } else {
            return this.upgradeTowerType(tower, upgradeType);
        }
    }

    /**
     * Upgrade tower level
     * @param {Object} tower 
     * @returns {Object}
     */
    upgradeTowerLevel(tower) {
        if (tower.level >= tower.maxLevel) {
            return {
                success: false,
                reason: 'Tower already at maximum level'
            };
        }

        const baseCost = this.towerTypes.get(tower.type).cost;
        const upgradeCost = Math.floor(baseCost * 0.5 * tower.level);

        // Check if player has enough resources
        if (this.resourceManager && !this.resourceManager.canAfford(upgradeCost)) {
            return {
                success: false,
                reason: 'Insufficient resources for upgrade'
            };
        }

        // Deduct resources
        if (this.resourceManager) {
            this.resourceManager.spendResources(upgradeCost);
        }

        // Apply level upgrade bonuses
        const bonusMultiplier = 1.3;
        tower.damage = Math.floor(tower.damage * bonusMultiplier);
        tower.range = Math.floor(tower.range * 1.1);
        tower.attackSpeed *= 1.1;
        
        tower.level++;
        tower.totalCost += upgradeCost;
        tower.sellValue = Math.floor(tower.totalCost * 0.7);

        // Show notification
        if (this.notificationManager) {
            this.notificationManager.showMessage(`Tower upgraded to level ${tower.level}!`, 'success');
        }

        this.triggerEvent('towerUpgraded', {
            tower,
            upgradeType: 'level',
            cost: upgradeCost
        });

        return {
            success: true,
            tower,
            cost: upgradeCost
        };
    }

    /**
     * Upgrade tower to different type
     * @param {Object} tower 
     * @param {string} newType 
     * @returns {Object}
     */
    upgradeTowerType(tower, newType) {
        if (!tower.availableUpgrades.includes(newType)) {
            return {
                success: false,
                reason: 'Upgrade not available for this tower'
            };
        }

        const newConfig = this.towerTypes.get(newType);
        if (!newConfig) {
            return {
                success: false,
                reason: 'Invalid upgrade type'
            };
        }

        const upgradeCost = newConfig.cost - this.towerTypes.get(tower.type).cost;

        // Check if player has enough resources
        if (this.resourceManager && !this.resourceManager.canAfford(upgradeCost)) {
            return {
                success: false,
                reason: 'Insufficient resources for upgrade'
            };
        }

        // Deduct resources
        if (this.resourceManager) {
            this.resourceManager.spendResources(upgradeCost);
        }

        // Update tower properties
        const oldType = tower.type;
        tower.type = newType;
        tower.damage = newConfig.damage;
        tower.range = newConfig.range;
        tower.attackSpeed = newConfig.attackSpeed;
        tower.projectileSpeed = newConfig.projectileSpeed;
        tower.projectileType = newConfig.projectileType;
        
        // Update special abilities
        tower.splashRadius = newConfig.splashRadius || 0;
        tower.splashDamage = newConfig.splashDamage || 0;
        tower.armorPiercing = newConfig.armorPiercing || false;
        tower.slowEffect = newConfig.slowEffect || null;
        tower.poisonEffect = newConfig.poisonEffect || null;
        tower.chainLightning = newConfig.chainLightning || null;
        
        tower.availableUpgrades = [...newConfig.upgrades];
        tower.maxLevel = newConfig.maxLevel;
        tower.totalCost += upgradeCost;
        tower.sellValue = Math.floor(tower.totalCost * 0.7);

        // Show notification
        if (this.notificationManager) {
            this.notificationManager.showMessage(`Tower upgraded to ${newConfig.name}!`, 'success');
        }

        this.triggerEvent('towerUpgraded', {
            tower,
            upgradeType: 'type',
            oldType,
            newType,
            cost: upgradeCost
        });

        return {
            success: true,
            tower,
            cost: upgradeCost
        };
    }

    /**
     * Sell a tower
     * @param {string} towerId 
     * @returns {Object} Sell result
     */
    sellTower(towerId) {
        const tower = this.towers.get(towerId);
        if (!tower) {
            return {
                success: false,
                reason: 'Tower not found'
            };
        }

        const sellValue = tower.sellValue;
        const gridKey = this.getGridKey(tower.x, tower.y);

        // Add resources back to player
        if (this.resourceManager) {
            this.resourceManager.addResources(sellValue);
        }

        // Remove from systems
        this.towers.delete(towerId);
        this.placementGrid.delete(gridKey);
        
        if (this.healthSystem) {
            this.healthSystem.unregisterEntity(towerId);
        }

        // Show notification
        if (this.notificationManager) {
            this.notificationManager.showMessage(`Tower sold for ${sellValue} resources`, 'info');
        }

        this.triggerEvent('towerSold', {
            tower,
            sellValue
        });

        return {
            success: true,
            sellValue,
            tower
        };
    }

    /**
     * Update tower combat behavior
     * @param {number} deltaTime 
     * @param {Array} enemies 
     */
    update(deltaTime, enemies = []) {
        const currentTime = Date.now();

        this.towers.forEach(tower => {
            if (tower.isBuilding) return;

            // Find target
            if (!tower.currentTarget || !this.isValidTarget(tower.currentTarget, tower)) {
                tower.currentTarget = this.findTarget(tower, enemies);
            }

            // Attack if target is available and cooldown is ready
            if (tower.currentTarget && this.canAttack(tower, currentTime)) {
                this.attackTarget(tower, tower.currentTarget);
                tower.lastAttackTime = currentTime;
            }
        });
    }

    /**
     * Find the best target for a tower
     * @param {Object} tower 
     * @param {Array} enemies 
     * @returns {Object|null}
     */
    findTarget(tower, enemies) {
        if (!this.targetingSystem) {
            // Simple targeting - closest enemy in range
            let closestEnemy = null;
            let closestDistance = Infinity;

            enemies.forEach(enemy => {
                if (!enemy.isAlive) return;
                
                const distance = this.getDistance(tower.x, tower.y, enemy.x, enemy.y);
                if (distance <= tower.range && distance < closestDistance) {
                    closestDistance = distance;
                    closestEnemy = enemy;
                }
            });

            return closestEnemy;
        }

        return this.targetingSystem.findTarget(tower, enemies);
    }

    /**
     * Check if tower can attack
     * @param {Object} tower 
     * @param {number} currentTime 
     * @returns {boolean}
     */
    canAttack(tower, currentTime) {
        const attackCooldown = 1000 / tower.attackSpeed; // ms between attacks
        return currentTime - tower.lastAttackTime >= attackCooldown;
    }

    /**
     * Check if target is still valid
     * @param {Object} target 
     * @param {Object} tower 
     * @returns {boolean}
     */
    isValidTarget(target, tower) {
        if (!target || !target.isAlive) return false;
        
        const distance = this.getDistance(tower.x, tower.y, target.x, target.y);
        return distance <= tower.range;
    }

    /**
     * Attack a target
     * @param {Object} tower 
     * @param {Object} target 
     */
    attackTarget(tower, target) {
        // Create projectile or instant hit
        const projectileData = {
            towerId: tower.id,
            startX: tower.x,
            startY: tower.y,
            targetX: target.x,
            targetY: target.y,
            target: target,
            damage: tower.damage,
            speed: tower.projectileSpeed,
            type: tower.projectileType,
            armorPiercing: tower.armorPiercing,
            splashRadius: tower.splashRadius,
            splashDamage: tower.splashDamage,
            slowEffect: tower.slowEffect,
            poisonEffect: tower.poisonEffect,
            chainLightning: tower.chainLightning
        };

        this.triggerEvent('towerAttack', {
            tower,
            target,
            projectile: projectileData
        });

        // Update tower stats
        tower.totalDamageDealt += tower.damage;
    }

    /**
     * Get distance between two points
     * @param {number} x1 
     * @param {number} y1 
     * @param {number} x2 
     * @param {number} y2 
     * @returns {number}
     */
    getDistance(x1, y1, x2, y2) {
        const dx = x2 - x1;
        const dy = y2 - y1;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Get grid key for position
     * @param {number} x 
     * @param {number} y 
     * @returns {string}
     */
    getGridKey(x, y) {
        const gridX = Math.floor(x / this.gridSize);
        const gridY = Math.floor(y / this.gridSize);
        return `${gridX},${gridY}`;
    }

    /**
     * Get tower by ID
     * @param {string} towerId 
     * @returns {Object|null}
     */
    getTower(towerId) {
        return this.towers.get(towerId) || null;
    }

    /**
     * Get all towers
     * @returns {Array}
     */
    getAllTowers() {
        return Array.from(this.towers.values());
    }

    /**
     * Get towers by player
     * @param {string} playerId 
     * @returns {Array}
     */
    getTowersByPlayer(playerId) {
        return this.getAllTowers().filter(tower => tower.playerId === playerId);
    }

    /**
     * Get tower types
     * @returns {Map}
     */
    getTowerTypes() {
        return new Map(this.towerTypes);
    }

    /**
     * Get tower type config
     * @param {string} towerType 
     * @returns {Object|null}
     */
    getTowerTypeConfig(towerType) {
        return this.towerTypes.get(towerType) || null;
    }

    /**
     * Add event listener
     * @param {string} event 
     * @param {Function} callback 
     */
    addEventListener(event, callback) {
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, []);
        }
        this.eventListeners.get(event).push(callback);
    }

    /**
     * Remove event listener
     * @param {string} event 
     * @param {Function} callback 
     */
    removeEventListener(event, callback) {
        const listeners = this.eventListeners.get(event);
        if (listeners) {
            const index = listeners.indexOf(callback);
            if (index > -1) {
                listeners.splice(index, 1);
            }
        }
    }

    /**
     * Trigger event
     * @param {string} event 
     * @param {Object} data 
     */
    triggerEvent(event, data) {
        const listeners = this.eventListeners.get(event);
        if (listeners) {
            listeners.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in ${event} event listener:`, error);
                }
            });
        }
    }

    /**
     * Get system statistics
     * @returns {Object}
     */
    getSystemStats() {
        const towers = this.getAllTowers();
        const totalTowers = towers.length;
        const buildingTowers = towers.filter(t => t.isBuilding).length;
        const totalDamage = towers.reduce((sum, t) => sum + t.totalDamageDealt, 0);
        const totalKills = towers.reduce((sum, t) => sum + t.kills, 0);
        const totalValue = towers.reduce((sum, t) => sum + t.totalCost, 0);

        return {
            totalTowers,
            buildingTowers,
            activeTowers: totalTowers - buildingTowers,
            totalDamage,
            totalKills,
            totalValue,
            occupiedGridCells: this.placementGrid.size
        };
    }

    /**
     * Clear all towers
     */
    clearAllTowers() {
        this.towers.forEach((tower, towerId) => {
            if (this.healthSystem) {
                this.healthSystem.unregisterEntity(towerId);
            }
        });
        
        this.towers.clear();
        this.placementGrid.clear();
        this.triggerEvent('allTowersCleared', {});
    }
}