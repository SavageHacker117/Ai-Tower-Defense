// Main Game Entry Point - Refactored with ES6 Modules and Dependency Injection
import * as THREE from 'three';
import { GameLoop } from './GameLoop.js';
import { ResourceManager } from './ResourceManager.js';
import { PlayerHealthSystem } from './PlayerHealthSystem.js';
import { AudioManager } from './AudioManager.js';
import { InputManager } from './InputManager.js';
import { NotificationManager } from './NotificationManager.js';
import { HUDManager } from './HUDManager.js';
import { EnemyUIManager } from './EnemyUIManager.js';
import { MapData } from './MapData.js';
import { LevelData } from './LevelData.js';
import { Pathfinding } from './Pathfinding.js';
import { EnemyFactory } from './enemy.js';
import { WaveManager } from './WaveManager.js';
import { TowerFactory, TOWER_DATA } from './tower.js'; // Assuming tower.js exists
import { MultiplayerManager } from './MultiplayerManager.js';
import { AuthManager } from './AuthManager.js';

// --- Placeholder Systems (ideally in separate files) ---
class TowerSystem {
    constructor({ scene, resourceManager, notificationManager, audioManager }) {
        this.scene = scene;
        this.resourceManager = resourceManager;
        this.notificationManager = notificationManager;
        this.audioManager = audioManager;
        this.towers = [];
        this.towerFactory = new TowerFactory(scene, resourceManager);
    }
    update(deltaTime, enemies, projectileSystem) {
        this.towers.forEach(tower => tower.update(deltaTime, enemies, projectileSystem));
    }
    placeTower(towerType, position) {
        const newTower = this.towerFactory.createTower(towerType, position);
        if (newTower) {
            this.towers.push(newTower);
            this.notificationManager.showSuccess(`${TOWER_DATA[towerType].name} built!`);
            this.audioManager.playSound('towerPlace');
            return true;
        }
        return false;
    }
    getTowers() { return this.towers; }
    getTowerData(type) { return TOWER_DATA[type]; }
    selectTower(tower) { console.log('Selected tower', tower); }
    deselectAll() { console.log('Deselecting all towers'); }
    upgradeTower(tower) { return tower.upgrade(); }
}
class ProjectileSystem {
    constructor({ scene, audioManager }) { this.scene = scene; this.audioManager = audioManager; this.projectiles = []; }
    update(deltaTime, enemies) { /* Projectile logic would go here */ }
    createProjectile(data) { console.log("Creating projectile", data); }
    getProjectiles() { return this.projectiles; }
}
class TargetingSystem {
    constructor({ getEnemies, getTowers }) { this.getEnemies = getEnemies; this.getTowers = getTowers; }
    update(deltaTime) { /* Targeting logic */ }
}
class StatusEffectSystem { update(deltaTime) {} }
class BossAISystem { update(deltaTime) {} }
class ParticleSystem { constructor({ scene }) { this.scene = scene; } createExplosion(pos, type) {} update(deltaTime) {} }
class VisualFeedbackSystem { update(deltaTime) {} }
class TowerStoreUI { constructor({ onTowerPurchase }) {} }

// --- Main Game Class ---
class Game {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.canvas = null;
        this.socket = null; // To hold the socket connection

        this.init();
    }

    async init() {
        console.log('Initializing Game...');
        await this.initThreeJS();
        await this.initGameSystems();
        this.setupEventListeners();
        this.hideLoadingScreen();
        this.startGame();
        console.log('Game Initialized Successfully!');
    }

    async initThreeJS() {
        this.canvas = document.getElementById('gameCanvas');
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x1d2953);
        this.camera = new THREE.PerspectiveCamera(75, this.canvas.width / this.canvas.height, 0.1, 1000);
        this.camera.position.set(0, 30, 25);
        this.camera.lookAt(0, 0, 0);
        this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
        this.renderer.setSize(this.canvas.width, this.canvas.height);
        this.renderer.shadowMap.enabled = true;
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 20, 15);
        directionalLight.castShadow = true;
        this.scene.add(directionalLight);
        const groundGeo = new THREE.PlaneGeometry(50, 50);
        const groundMat = new THREE.MeshStandardMaterial({ color: 0x346751 });
        const ground = new THREE.Mesh(groundGeo, groundMat);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);
    }

    async initGameSystems() {
        // --- Core Managers ---
        this.notificationManager = new NotificationManager();
        this.audioManager = new AudioManager();
        await this.audioManager.init();
        
        // --- Backend and Multiplayer ---
        this.socket = io('http://127.0.0.1:5000'); // Initialize Socket.IO connection
        this.authManager = new AuthManager();
        this.multiplayerManager = new MultiplayerManager({
            authManager: this.authManager,
            notificationManager: this.notificationManager,
            socket: this.socket,
            eventBus: this // The Game class can act as an event bus
        });

        // --- Gameplay Systems ---
        this.resourceManager = new ResourceManager({ notificationManager: this.notificationManager });
        this.playerHealthSystem = new PlayerHealthSystem(20, { notificationManager: this.notificationManager });
        this.levelData = new LevelData();
        this.mapData = new MapData();
        await this.mapData.loadLevel(1);
        this.pathfinding = new Pathfinding();
        this.pathfinding.initializeGrid(this.mapData);
        this.enemyPath = this.pathfinding.generatePath(this.mapData.getSpawnPoint(), this.mapData.getEndPoint());

        this.enemies = [];
        this.enemyFactory = new EnemyFactory({ levelData: this.levelData });
        
        this.projectileSystem = new ProjectileSystem({ scene: this.scene, audioManager: this.audioManager });
        this.towerSystem = new TowerSystem({ scene: this.scene, resourceManager: this.resourceManager, notificationManager: this.notificationManager, audioManager: this.audioManager });

        this.waveManager = new WaveManager({
            levelData: this.levelData,
            notificationManager: this.notificationManager,
            addEnemy: (enemy) => this.addEnemy(enemy),
            getEnemyPath: () => this.enemyPath
        });

        // --- UI and Input ---
        this.hudManager = new HUDManager({
            resourceManager: this.resourceManager,
            playerHealthSystem: this.playerHealthSystem,
            waveManager: this.waveManager,
            getTowers: () => this.towerSystem.getTowers(),
            getEnemies: () => this.enemies,
            getEnemyPath: () => this.enemyPath,
            isPaused: () => this.isPaused,
            gameSpeed: () => this.gameSpeed
        });
        this.enemyUIManager = new EnemyUIManager({ camera: this.camera, renderer: this.renderer, gameContainer: document.getElementById('gameContainer') });
        this.inputManager = new InputManager({
            audioManager: this.audioManager,
            notificationManager: this.notificationManager,
            resourceManager: this.resourceManager,
            towerSystem: this.towerSystem,
            getCamera: () => this.camera,
            getRenderer: () => this.renderer,
            getScene: () => this.scene,
            getTowers: () => this.towerSystem.getTowers(),
            getEnemies: () => this.enemies,
            getEnemyPath: () => this.enemyPath,
            togglePause: () => this.togglePause()
        });
        
        // --- Game Loop ---
        this.gameLoop = new GameLoop({
            updateCallback: (dt) => this.update(dt),
            renderCallback: () => this.render(),
            notificationManager: this.notificationManager
        });
        
        // --- Event Bus for Remote Events ---
        this.addEventListener('remoteTowerPlaced', (data) => {
            this.towerSystem.placeTower(data.type, data.position);
        });
    }

    setupEventListeners() {
        // Event listeners for UI buttons, etc. will go here.
        // For example:
        // document.getElementById('loginButton').addEventListener('click', async () => {
        //     const result = await this.authManager.login('user', 'password');
        //     if (result.success) this.notificationManager.showSuccess('Login successful!');
        // });
        
        // This connects the tower placement in the input manager to the multiplayer sync
        this.inputManager.onTowerPlace = (towerType, position) => {
            const success = this.towerSystem.placeTower(towerType, position);
            if (success) {
                // If placement is successful, notify the server
                this.multiplayerManager.syncTowerPlacement(towerType, position);
            }
        };
    }
    
    // Simple internal event bus
    addEventListener(event, callback) {
        if (!this._events) this._events = {};
        if (!this._events[event]) this._events[event] = [];
        this._events[event].push(callback);
    }
    triggerEvent(event, data) {
        if (this._events && this._events[event]) {
            this._events[event].forEach(callback => callback(data));
        }
    }

    addEnemy(enemy) {
        this.enemies.push(enemy);
        this.scene.add(enemy.mesh);
        enemy.setDependencies({ enemyUIManager: this.enemyUIManager });
    }

    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) loadingScreen.style.display = 'none';
    }

    startGame() {
        this.isPaused = false;
        this.gameSpeed = 1;
        this.gameLoop.start();
        this.audioManager.playBackgroundMusic();
    }
    
    togglePause() {
        this.isPaused = !this.isPaused;
        this.notificationManager.showInfo(this.isPaused ? 'Game Paused' : 'Game Resumed');
    }

    update(deltaTime) {
        if (this.isPaused) return;

        const dt = deltaTime * this.gameSpeed;
        this.waveManager.update(dt);
        this.enemies.forEach(enemy => enemy.update(dt, this.enemyPath));
        this.towerSystem.update(dt, this.enemies, this.projectileSystem);
        this.projectileSystem.update(dt, this.enemies);
        this.enemyUIManager.update(this.enemies);
        this.hudManager.update();
        // Check for game over, etc.
    }

    render() {
        this.renderer.render(this.scene, this.camera);
    }
}

// Initialize game when page loads
window.addEventListener('load', () => {
    const game = new Game();
    window.game = game; // For easy debugging
});