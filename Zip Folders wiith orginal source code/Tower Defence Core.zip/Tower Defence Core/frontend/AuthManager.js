/**
 * AuthManager.js
 * Handles user authentication, session management, and user data persistence
 * for the tower defense game
 */

export class AuthManager {
    constructor() {
        this.currentUser = null;
        this.sessionToken = null;
        this.isLoggedIn = false;
        this.userStats = {};
        this.gameProgress = {};
        
        // Initialize from localStorage if available
        this.loadSession();
    }

    /**
     * Register a new user
     * @param {string} username 
     * @param {string} email 
     * @param {string} password 
     * @returns {Promise<Object>} Registration result
     */
    async register(username, email, password) {
        try {
            // Validate input
            if (!this.validateUsername(username)) {
                throw new Error('Invalid username. Must be 3-20 characters, alphanumeric only.');
            }
            
            if (!this.validateEmail(email)) {
                throw new Error('Invalid email format.');
            }
            
            if (!this.validatePassword(password)) {
                throw new Error('Password must be at least 8 characters with uppercase, lowercase, and number.');
            }

            // Check if user already exists (in real app, this would be server-side)
            const existingUser = localStorage.getItem(`user_${username}`);
            if (existingUser) {
                throw new Error('Username already exists.');
            }

            // Hash password (simplified for demo - use proper hashing in production)
            const hashedPassword = await this.hashPassword(password);
            
            // Create user object
            const userData = {
                username,
                email,
                password: hashedPassword,
                createdAt: new Date().toISOString(),
                level: 1,
                experience: 0,
                currency: 1000,
                unlockedTowers: ['basic'],
                achievements: [],
                gamesPlayed: 0,
                gamesWon: 0
            };

            // Store user data
            localStorage.setItem(`user_${username}`, JSON.stringify(userData));
            
            return {
                success: true,
                message: 'Registration successful',
                user: { username, email, level: 1 }
            };
            
        } catch (error) {
            return {
                success: false,
                message: error.message
            };
        }
    }

    /**
     * Login user
     * @param {string} username 
     * @param {string} password 
     * @returns {Promise<Object>} Login result
     */
    async login(username, password) {
        try {
            // Get user data
            const userDataStr = localStorage.getItem(`user_${username}`);
            if (!userDataStr) {
                throw new Error('User not found.');
            }

            const userData = JSON.parse(userDataStr);
            
            // Verify password
            const isValidPassword = await this.verifyPassword(password, userData.password);
            if (!isValidPassword) {
                throw new Error('Invalid password.');
            }

            // Create session
            this.currentUser = userData;
            this.sessionToken = this.generateSessionToken();
            this.isLoggedIn = true;
            
            // Save session
            this.saveSession();
            
            // Update last login
            userData.lastLogin = new Date().toISOString();
            localStorage.setItem(`user_${username}`, JSON.stringify(userData));

            return {
                success: true,
                message: 'Login successful',
                user: {
                    username: userData.username,
                    level: userData.level,
                    currency: userData.currency,
                    experience: userData.experience
                }
            };
            
        } catch (error) {
            return {
                success: false,
                message: error.message
            };
        }
    }

    /**
     * Logout current user
     */
    logout() {
        this.currentUser = null;
        this.sessionToken = null;
        this.isLoggedIn = false;
        
        // Clear session storage
        localStorage.removeItem('currentSession');
        localStorage.removeItem('sessionToken');
        
        return {
            success: true,
            message: 'Logged out successfully'
        };
    }

    /**
     * Get current user data
     * @returns {Object|null} Current user data
     */
    getCurrentUser() {
        return this.currentUser;
    }

    /**
     * Update user stats after game completion
     * @param {Object} gameStats 
     */
    updateUserStats(gameStats) {
        if (!this.isLoggedIn || !this.currentUser) return;

        const { score, enemiesKilled, wavesCompleted, gameWon, experienceGained, currencyEarned } = gameStats;
        
        // Update user data
        this.currentUser.gamesPlayed++;
        if (gameWon) this.currentUser.gamesWon++;
        
        this.currentUser.experience += experienceGained || 0;
        this.currentUser.currency += currencyEarned || 0;
        
        // Check for level up
        this.checkLevelUp();
        
        // Save updated data
        localStorage.setItem(`user_${this.currentUser.username}`, JSON.stringify(this.currentUser));
        this.saveSession();
    }

    /**
     * Check if user should level up
     */
    checkLevelUp() {
        const expNeeded = this.currentUser.level * 1000;
        if (this.currentUser.experience >= expNeeded) {
            this.currentUser.level++;
            this.currentUser.experience -= expNeeded;
            
            // Unlock new towers based on level
            this.unlockTowersByLevel();
            
            return true;
        }
        return false;
    }

    /**
     * Unlock towers based on user level
     */
    unlockTowersByLevel() {
        const towerUnlocks = {
            2: 'cannon',
            3: 'laser',
            5: 'ice',
            7: 'poison',
            10: 'lightning'
        };
        
        const newTower = towerUnlocks[this.currentUser.level];
        if (newTower && !this.currentUser.unlockedTowers.includes(newTower)) {
            this.currentUser.unlockedTowers.push(newTower);
        }
    }

    /**
     * Save current session to localStorage
     */
    saveSession() {
        if (this.isLoggedIn && this.currentUser) {
            localStorage.setItem('currentSession', JSON.stringify(this.currentUser));
            localStorage.setItem('sessionToken', this.sessionToken);
        }
    }

    /**
     * Load session from localStorage
     */
    loadSession() {
        try {
            const sessionData = localStorage.getItem('currentSession');
            const token = localStorage.getItem('sessionToken');
            
            if (sessionData && token) {
                this.currentUser = JSON.parse(sessionData);
                this.sessionToken = token;
                this.isLoggedIn = true;
            }
        } catch (error) {
            console.error('Failed to load session:', error);
            this.logout();
        }
    }

    /**
     * Validate username format
     * @param {string} username 
     * @returns {boolean}
     */
    validateUsername(username) {
        const usernameRegex = /^[a-zA-Z0-9]{3,20}$/;
        return usernameRegex.test(username);
    }

    /**
     * Validate email format
     * @param {string} email 
     * @returns {boolean}
     */
    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Validate password strength
     * @param {string} password 
     * @returns {boolean}
     */
    validatePassword(password) {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
        return passwordRegex.test(password);
    }

    /**
     * Simple password hashing (use proper hashing in production)
     * @param {string} password 
     * @returns {Promise<string>}
     */
    async hashPassword(password) {
        // This is a simplified hash for demo purposes
        // In production, use bcrypt or similar
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash.toString();
    }

    /**
     * Verify password against hash
     * @param {string} password 
     * @param {string} hash 
     * @returns {Promise<boolean>}
     */
    async verifyPassword(password, hash) {
        const passwordHash = await this.hashPassword(password);
        return passwordHash === hash;
    }

    /**
     * Generate session token
     * @returns {string}
     */
    generateSessionToken() {
        return Math.random().toString(36).substring(2) + Date.now().toString(36);
    }

    /**
     * Check if user has permission for certain actions
     * @param {string} action 
     * @returns {boolean}
     */
    hasPermission(action) {
        if (!this.isLoggedIn) return false;
        
        const permissions = {
            'play_game': true,
            'save_progress': true,
            'access_store': this.currentUser.level >= 2,
            'multiplayer': this.currentUser.level >= 5,
            'leaderboard': this.currentUser.gamesPlayed >= 1
        };
        
        return permissions[action] || false;
    }
}