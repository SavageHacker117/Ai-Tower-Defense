/**
 * MultiplayerManager.js
 * Manages multiplayer game coordination, networking, and synchronization
 * for the tower defense game
 * 
 * Refactored to use ES6 modules and dependency injection
 */

export class MultiplayerManager {
    constructor({ authManager, notificationManager, eventBus }) {
        // Injected dependencies
        this.authManager = authManager;
        this.notificationManager = notificationManager;
        this.eventBus = eventBus;
        
        this.isHost = false;
        this.isConnected = false;
        this.gameRoom = null;
        this.players = new Map(); // playerId -> playerData
        this.eventListeners = new Map();
        
        this.connection = null;
        this.messageQueue = [];
        this.syncInterval = null;
        this.lastSyncTime = 0;
        
        this.gameState = {
            wave: 1,
            enemies: [],
            towers: [],
            gameTime: 0,
            isPaused: false,
            gameStarted: false
        };
        
        this.initializeNetworking();
        this.bindEventHandlers();
    }

    /**
     * Initialize networking components
     */
    initializeNetworking() {
        // This would integrate with a real networking solution
        // For demo purposes, we'll simulate networking
        this.networkSimulation = {
            latency: 50, // ms
            packetLoss: 0.01, // 1%
            connected: false
        };
    }

    /**
     * Bind event handlers to the event bus
     */
    bindEventHandlers() {
        // Listen for game events that need to be synchronized
        this.eventBus.addEventListener('towerPlaced', (data) => {
            this.syncTowerPlacement(data);
        });
        
        this.eventBus.addEventListener('towerUpgraded', (data) => {
            this.syncTowerUpgrade(data);
        });
        
        this.eventBus.addEventListener('waveStarted', (data) => {
            if (this.isHost) {
                this.syncWaveStart(data.wave, data.waveData);
            }
        });
        
        this.eventBus.addEventListener('resourcesChanged', (data) => {
            this.syncPlayerResources(data);
        });
    }

    /**
     * Create a new multiplayer game room
     * @param {Object} roomConfig 
     * @returns {Promise<Object>}
     */
    async createRoom(roomConfig = {}) {
        try {
            if (!this.authManager.isLoggedIn) {
                throw new Error('Must be logged in to create room');
            }

            const user = this.authManager.getCurrentUser();
            const roomId = this.generateRoomId();
            
            this.gameRoom = {
                id: roomId,
                name: roomConfig.name || `${user.username}'s Game`,
                hostId: user.username,
                maxPlayers: roomConfig.maxPlayers || 4,
                isPrivate: roomConfig.isPrivate || false,
                password: roomConfig.password || null,
                gameMode: roomConfig.gameMode || 'cooperative',
                difficulty: roomConfig.difficulty || 'normal',
                map: roomConfig.map || 'default',
                createdAt: new Date().toISOString(),
                players: [],
                gameState: 'waiting', // waiting, starting, playing, paused, ended
                settings: {
                    friendlyFire: roomConfig.friendlyFire || false,
                    sharedResources: roomConfig.sharedResources || true,
                    allowSpectators: roomConfig.allowSpectators || true,
                    autoStart: roomConfig.autoStart || false
                }
            };

            this.isHost = true;
            this.isConnected = true;

            // Add host as first player
            await this.addPlayer(user.username, {
                username: user.username,
                level: user.level,
                isHost: true,
                isReady: false,
                team: 1,
                color: '#FF0000'
            });

            this.startSyncLoop();

            // Notify via event bus
            this.eventBus.triggerEvent('roomCreated', {
                room: this.gameRoom,
                playerId: user.username
            });

            // Show notification
            this.notificationManager.show(`Room ${roomId} created successfully!`, 'success');

            return {
                success: true,
                roomId,
                room: this.gameRoom
            };

        } catch (error) {
            this.notificationManager.show(`Failed to create room: ${error.message}`, 'error');
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Join an existing multiplayer game room
     * @param {string} roomId 
     * @param {string} password 
     * @returns {Promise<Object>}
     */
    async joinRoom(roomId, password = null) {
        try {
            if (!this.authManager.isLoggedIn) {
                throw new Error('Must be logged in to join room');
            }

            const user = this.authManager.getCurrentUser();

            // Simulate room lookup
            const roomData = await this.findRoom(roomId);
            if (!roomData) {
                throw new Error('Room not found');
            }

            if (roomData.isPrivate && roomData.password !== password) {
                throw new Error('Invalid password');
            }

            if (roomData.players.length >= roomData.maxPlayers) {
                throw new Error('Room is full');
            }

            this.gameRoom = roomData;
            this.isHost = false;
            this.isConnected = true;

            // Add player to room
            await this.addPlayer(user.username, {
                username: user.username,
                level: user.level,
                isHost: false,
                isReady: false,
                team: this.assignTeam(),
                color: this.assignColor()
            });

            this.startSyncLoop();

            // Notify via event bus
            this.eventBus.triggerEvent('roomJoined', {
                room: this.gameRoom,
                playerId: user.username
            });

            // Show notification
            this.notificationManager.show(`Joined room ${roomId}!`, 'success');

            return {
                success: true,
                room: this.gameRoom
            };

        } catch (error) {
            this.notificationManager.show(`Failed to join room: ${error.message}`, 'error');
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Leave the current multiplayer room
     * @returns {Promise<Object>}
     */
    async leaveRoom() {
        try {
            if (!this.isConnected || !this.gameRoom) {
                throw new Error('Not in a room');
            }

            const user = this.authManager.getCurrentUser();
            
            // Remove player from room
            await this.removePlayer(user.username);

            // If host is leaving, transfer host or close room
            if (this.isHost) {
                await this.handleHostLeaving();
            }

            const roomId = this.gameRoom.id;
            this.cleanup();

            // Notify via event bus
            this.eventBus.triggerEvent('roomLeft', {
                roomId,
                playerId: user.username
            });

            // Show notification
            this.notificationManager.show('Left multiplayer room', 'info');

            return {
                success: true
            };

        } catch (error) {
            this.notificationManager.show(`Error leaving room: ${error.message}`, 'error');
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Add player to the room
     * @param {string} playerId 
     * @param {Object} playerData 
     */
    async addPlayer(playerId, playerData) {
        if (!this.gameRoom) return;

        const player = {
            id: playerId,
            ...playerData,
            joinedAt: new Date().toISOString(),
            ping: 0,
            isConnected: true,
            currency: 1000,
            score: 0,
            towersBuilt: 0,
            enemiesKilled: 0
        };

        this.players.set(playerId, player);
        this.gameRoom.players.push(player);

        this.broadcastMessage('playerJoined', {
            player,
            roomState: this.gameRoom
        });

        // Notify via event bus
        this.eventBus.triggerEvent('playerJoined', {
            player,
            room: this.gameRoom
        });

        // Show notification
        this.notificationManager.show(`${player.username} joined the game`, 'info');
    }

    /**
     * Remove player from the room
     * @param {string} playerId 
     */
    async removePlayer(playerId) {
        if (!this.gameRoom) return;

        const player = this.players.get(playerId);
        if (!player) return;

        this.players.delete(playerId);
        this.gameRoom.players = this.gameRoom.players.filter(p => p.id !== playerId);

        this.broadcastMessage('playerLeft', {
            playerId,
            roomState: this.gameRoom
        });

        // Notify via event bus
        this.eventBus.triggerEvent('playerLeft', {
            playerId,
            player,
            room: this.gameRoom
        });

        // Show notification
        this.notificationManager.show(`${player.username} left the game`, 'info');
    }

    /**
     * Set player ready status
     * @param {boolean} isReady 
     */
    setPlayerReady(isReady) {
        if (!this.authManager.isLoggedIn || !this.gameRoom) return;

        const user = this.authManager.getCurrentUser();
        const player = this.players.get(user.username);
        
        if (player) {
            player.isReady = isReady;
            
            this.broadcastMessage('playerReadyChanged', {
                playerId: user.username,
                isReady
            });

            // Notify via event bus
            this.eventBus.triggerEvent('playerReadyChanged', {
                playerId: user.username,
                isReady,
                allReady: this.areAllPlayersReady()
            });

            // Show notification
            this.notificationManager.show(
                isReady ? 'You are ready!' : 'You are not ready', 
                'info'
            );

            // Auto-start if all players are ready
            if (this.isHost && this.gameRoom.settings.autoStart && this.areAllPlayersReady()) {
                this.startGame();
            }
        }
    }

    /**
     * Start the multiplayer game
     */
    async startGame() {
        if (!this.isHost || !this.gameRoom) {
            throw new Error('Only host can start the game');
        }

        if (!this.areAllPlayersReady()) {
            throw new Error('Not all players are ready');
        }

        this.gameRoom.gameState = 'starting';
        this.gameState.gameStarted = true;
        this.gameState.gameTime = 0;

        this.broadcastMessage('gameStarting', {
            countdown: 3,
            gameSettings: this.gameRoom.settings
        });

        // Show countdown notification
        this.notificationManager.show('Game starting in 3...', 'info');

        // Countdown
        for (let i = 3; i > 0; i--) {
            this.broadcastMessage('gameCountdown', { count: i });
            await this.delay(1000);
        }

        this.gameRoom.gameState = 'playing';
        
        this.broadcastMessage('gameStarted', {
            gameState: this.gameState,
            roomState: this.gameRoom
        });

        // Notify via event bus
        this.eventBus.triggerEvent('multiplayerGameStarted', {
            room: this.gameRoom,
            gameState: this.gameState
        });

        // Show notification
        this.notificationManager.show('Multiplayer game started!', 'success');
    }

    /**
     * Pause/unpause the multiplayer game
     * @param {boolean} isPaused 
     */
    pauseGame(isPaused) {
        if (!this.isHost) return;

        this.gameState.isPaused = isPaused;
        this.gameRoom.gameState = isPaused ? 'paused' : 'playing';

        this.broadcastMessage('gamePaused', {
            isPaused,
            gameState: this.gameState
        });

        // Notify via event bus
        this.eventBus.triggerEvent('multiplayerGamePaused', {
            isPaused,
            gameState: this.gameState
        });

        // Show notification
        this.notificationManager.show(
            isPaused ? 'Game paused' : 'Game resumed', 
            'info'
        );
    }

    /**
     * End the multiplayer game
     * @param {Object} results 
     */
    endGame(results = {}) {
        if (!this.isHost) return;

        this.gameRoom.gameState = 'ended';
        this.gameState.gameStarted = false;

        const finalResults = {
            victory: results.victory || false,
            wave: this.gameState.wave,
            gameTime: this.gameState.gameTime,
            players: Array.from(this.players.values()).map(player => ({
                id: player.id,
                username: player.username,
                score: player.score,
                towersBuilt: player.towersBuilt,
                enemiesKilled: player.enemiesKilled,
                currency: player.currency
            })),
            ...results
        };

        this.broadcastMessage('gameEnded', {
            results: finalResults,
            gameState: this.gameState
        });

        // Notify via event bus
        this.eventBus.triggerEvent('multiplayerGameEnded', {
            results: finalResults,
            room: this.gameRoom
        });

        // Show notification
        this.notificationManager.show(
            results.victory ? 'Victory!' : 'Game Over', 
            results.victory ? 'success' : 'error'
        );
    }

    /**
     * Synchronize tower placement
     * @param {Object} towerData 
     */
    syncTowerPlacement(towerData) {
        if (!this.isConnected) return;

        const message = {
            type: 'towerPlaced',
            data: {
                ...towerData,
                playerId: this.authManager.getCurrentUser()?.username,
                timestamp: Date.now()
            }
        };

        this.broadcastMessage('towerPlaced', message.data);
        
        // Notify via event bus
        this.eventBus.triggerEvent('towerSynced', message.data);
    }

    /**
     * Synchronize tower upgrade
     * @param {Object} upgradeData 
     */
    syncTowerUpgrade(upgradeData) {
        if (!this.isConnected) return;

        const message = {
            type: 'towerUpgraded',
            data: {
                ...upgradeData,
                playerId: this.authManager.getCurrentUser()?.username,
                timestamp: Date.now()
            }
        };

        this.broadcastMessage('towerUpgraded', message.data);
        
        // Notify via event bus
        this.eventBus.triggerEvent('towerUpgradeSynced', message.data);
    }

    /**
     * Synchronize enemy spawn
     * @param {Object} enemyData 
     */
    syncEnemySpawn(enemyData) {
        if (!this.isHost) return;

        const message = {
            type: 'enemySpawned',
            data: {
                ...enemyData,
                timestamp: Date.now()
            }
        };

        this.broadcastMessage('enemySpawned', message.data);
    }

    /**
     * Synchronize wave progression
     * @param {number} waveNumber 
     * @param {Object} waveData 
     */
    syncWaveStart(waveNumber, waveData) {
        if (!this.isHost) return;

        this.gameState.wave = waveNumber;

        const message = {
            type: 'waveStarted',
            data: {
                wave: waveNumber,
                waveData,
                timestamp: Date.now()
            }
        };

        this.broadcastMessage('waveStarted', message.data);
        
        // Notify via event bus
        this.eventBus.triggerEvent('waveSynced', message.data);
    }

    /**
     * Synchronize player resources
     * @param {Object} resourceData 
     */
    syncPlayerResources(resourceData) {
        if (!this.isConnected) return;

        const user = this.authManager.getCurrentUser();
        if (!user) return;

        const player = this.players.get(user.username);
        if (player) {
            Object.assign(player, resourceData);
        }

        const message = {
            type: 'resourcesUpdated',
            data: {
                playerId: user.username,
                ...resourceData,
                timestamp: Date.now()
            }
        };

        this.broadcastMessage('resourcesUpdated', message.data);
    }

    /**
     * Send chat message
     * @param {string} message 
     * @param {string} type 
     */
    sendChatMessage(message, type = 'public') {
        if (!this.isConnected) return;

        const user = this.authManager.getCurrentUser();
        if (!user) return;

        const chatMessage = {
            id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            playerId: user.username,
            playerName: user.username,
            message,
            type, // public, team, private
            timestamp: Date.now()
        };

        this.broadcastMessage('chatMessage', chatMessage);
        
        // Notify via event bus
        this.eventBus.triggerEvent('chatMessage', chatMessage);
    }

    /**
     * Handle incoming network message
     * @param {Object} message 
     */
    handleMessage(message) {
        try {
            switch (message.type) {
                case 'playerJoined':
                    this.handlePlayerJoined(message.data);
                    break;
                case 'playerLeft':
                    this.handlePlayerLeft(message.data);
                    break;
                case 'playerReadyChanged':
                    this.handlePlayerReadyChanged(message.data);
                    break;
                case 'towerPlaced':
                    this.handleTowerPlaced(message.data);
                    break;
                case 'towerUpgraded':
                    this.handleTowerUpgraded(message.data);
                    break;
                case 'enemySpawned':
                    this.handleEnemySpawned(message.data);
                    break;
                case 'waveStarted':
                    this.handleWaveStarted(message.data);
                    break;
                case 'resourcesUpdated':
                    this.handleResourcesUpdated(message.data);
                    break;
                case 'chatMessage':
                    this.handleChatMessage(message.data);
                    break;
                case 'gameStarting':
                case 'gameStarted':
                case 'gamePaused':
                case 'gameEnded':
                    this.handleGameStateChange(message);
                    break;
                case 'ping':
                    this.handlePing(message.data);
                    break;
                case 'sync':
                    this.handleSync(message.data);
                    break;
            }
        } catch (error) {
            console.error('Error handling message:', error);
            this.notificationManager.show('Network error occurred', 'error');
        }
    }

    /**
     * Handle player joined message
     * @param {Object} data 
     */
    handlePlayerJoined(data) {
        if (data.player && !this.players.has(data.player.id)) {
            this.players.set(data.player.id, data.player);
            
            // Notify via event bus
            this.eventBus.triggerEvent('remotePlayerJoined', data);
        }
    }

    /**
     * Handle player left message
     * @param {Object} data 
     */
    handlePlayerLeft(data) {
        if (this.players.has(data.playerId)) {
            const player = this.players.get(data.playerId);
            this.players.delete(data.playerId);
            
            // Notify via event bus
            this.eventBus.triggerEvent('remotePlayerLeft', { ...data, player });
        }
    }

    /**
     * Handle player ready status change
     * @param {Object} data 
     */
    handlePlayerReadyChanged(data) {
        const player = this.players.get(data.playerId);
        if (player) {
            player.isReady = data.isReady;
            
            // Notify via event bus
            this.eventBus.triggerEvent('remotePlayerReadyChanged', data);
        }
    }

    /**
     * Handle tower placement sync
     * @param {Object} data 
     */
    handleTowerPlaced(data) {
        // Notify via event bus
        this.eventBus.triggerEvent('remoteTowerPlaced', data);
    }

    /**
     * Handle tower upgrade sync
     * @param {Object} data 
     */
    handleTowerUpgraded(data) {
        // Notify via event bus
        this.eventBus.triggerEvent('remoteTowerUpgraded', data);
    }

    /**
     * Handle enemy spawn sync
     * @param {Object} data 
     */
    handleEnemySpawned(data) {
        // Notify via event bus
        this.eventBus.triggerEvent('remoteEnemySpawned', data);
    }

    /**
     * Handle wave start sync
     * @param {Object} data 
     */
    handleWaveStarted(data) {
        this.gameState.wave = data.wave;
        
        // Notify via event bus
        this.eventBus.triggerEvent('remoteWaveStarted', data);
    }

    /**
     * Handle resource update sync
     * @param {Object} data 
     */
    handleResourcesUpdated(data) {
        const player = this.players.get(data.playerId);
        if (player) {
            Object.assign(player, data);
            
            // Notify via event bus
            this.eventBus.triggerEvent('remoteResourcesUpdated', data);
        }
    }

    /**
     * Handle chat message
     * @param {Object} data 
     */
    handleChatMessage(data) {
        // Notify via event bus
        this.eventBus.triggerEvent('remoteChatMessage', data);
    }

    /**
     * Handle game state changes
     * @param {Object} message 
     */
    handleGameStateChange(message) {
        // Notify via event bus
        this.eventBus.triggerEvent(`remote${message.type.charAt(0).toUpperCase() + message.type.slice(1)}`, message.data);
    }

    /**
     * Handle ping message
     * @param {Object} data 
     */
    handlePing(data) {
        const player = this.players.get(data.playerId);
        if (player) {
            player.ping = data.ping;
        }
    }

    /**
     * Handle sync message
     * @param {Object} data 
     */
    handleSync(data) {
        // Update game state from host
        if (data.gameState) {
            Object.assign(this.gameState, data.gameState);
        }
        
        // Notify via event bus
        this.eventBus.triggerEvent('gameStateSynced', data);
    }

    /**
     * Broadcast message to all players
     * @param {string} type 
     * @param {Object} data 
     */
    broadcastMessage(type, data) {
        const message = {
            type,
            data,
            timestamp: Date.now(),
            senderId: this.authManager.getCurrentUser()?.username
        };

        // Simulate network delay and packet loss
        setTimeout(() => {
            if (Math.random() > this.networkSimulation.packetLoss) {
                this.messageQueue.push(message);
            }
        }, this.networkSimulation.latency);
    }

    /**
     * Start synchronization loop
     */
    startSyncLoop() {
        if (this.syncInterval) return;

        this.syncInterval = setInterval(() => {
            this.performSync();
            this.sendPing();
        }, 1000); // Sync every second
    }

    /**
     * Stop synchronization loop
     */
    stopSyncLoop() {
        if (this.syncInterval) {
            clearInterval(this.syncInterval);
            this.syncInterval = null;
        }
    }

    /**
     * Perform periodic synchronization
     */
    performSync() {
        if (!this.isHost || !this.isConnected) return;

        const syncData = {
            gameState: this.gameState,
            players: Array.from(this.players.values()),
            timestamp: Date.now()
        };

        this.broadcastMessage('sync', syncData);
    }

    /**
     * Send ping to measure latency
     */
    sendPing() {
        if (!this.isConnected) return;

        const user = this.authManager.getCurrentUser();
        if (!user) return;

        const pingData = {
            playerId: user.username,
            timestamp: Date.now()
        };

        this.broadcastMessage('ping', pingData);
    }

    /**
     * Check if all players are ready
     * @returns {boolean}
     */
    areAllPlayersReady() {
        const players = Array.from(this.players.values());
        return players.length > 0 && players.every(player => player.isReady);
    }

    /**
     * Assign team to new player
     * @returns {number}
     */
    assignTeam() {
        // Simple team assignment - alternate between teams
        const players = Array.from(this.players.values());
        const team1Count = players.filter(p => p.team === 1).length;
        const team2Count = players.filter(p => p.team === 2).length;
        
        return team1Count <= team2Count ? 1 : 2;
    }

    /**
     * Assign color to new player
     * @returns {string}
     */
    assignColor() {
        const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF'];
        const usedColors = Array.from(this.players.values()).map(p => p.color);
        
        for (const color of colors) {
            if (!usedColors.includes(color)) {
                return color;
            }
        }
        
        return '#FFFFFF'; // Fallback
    }

    /**
     * Handle host leaving
     */
    async handleHostLeaving() {
        const players = Array.from(this.players.values()).filter(p => p.id !== this.authManager.getCurrentUser()?.username);
        
        if (players.length > 0) {
            // Transfer host to next player
            const newHost = players[0];
            newHost.isHost = true;
            this.gameRoom.hostId = newHost.id;
            
            this.broadcastMessage('hostTransferred', {
                newHostId: newHost.id,
                roomState: this.gameRoom
            });
            
            this.notificationManager.show(`Host transferred to ${newHost.username}`, 'info');
        } else {
            // Close room if no players left
            this.broadcastMessage('roomClosed', {
                roomId: this.gameRoom.id
            });
        }
    }

    /**
     * Find room by ID (simulated)
     * @param {string} roomId 
     * @returns {Promise<Object|null>}
     */
    async findRoom(roomId) {
        // Simulate room lookup
        await this.delay(100);
        
        // For demo, return a mock room
        return {
            id: roomId,
            name: 'Test Room',
            hostId: 'testhost',
            maxPlayers: 4,
            isPrivate: false,
            password: null,
            gameMode: 'cooperative',
            difficulty: 'normal',
            map: 'default',
            players: [],
            gameState: 'waiting',
            settings: {
                friendlyFire: false,
                sharedResources: true,
                allowSpectators: true,
                autoStart: false
            }
        };
    }

    /**
     * Generate unique room ID
     * @returns {string}
     */
    generateRoomId() {
        return Math.random().toString(36).substr(2, 9).toUpperCase();
    }

    /**
     * Utility delay function
     * @param {number} ms 
     * @returns {Promise}
     */
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * Cleanup resources
     */
    cleanup() {
        this.stopSyncLoop();
        this.isConnected = false;
        this.isHost = false;
        this.gameRoom = null;
        this.players.clear();
        this.messageQueue.length = 0;
        
        // Clean up event listeners
        this.eventListeners.clear();
    }

    /**
     * Get current room info
     * @returns {Object|null}
     */
    getCurrentRoom() {
        return this.gameRoom;
    }

    /**
     * Get all players
     * @returns {Array}
     */
    getPlayers() {
        return Array.from(this.players.values());
    }

    /**
     * Get player by ID
     * @param {string} playerId 
     * @returns {Object|null}
     */
    getPlayer(playerId) {
        return this.players.get(playerId) || null;
    }

    /**
     * Check if connected to multiplayer
     * @returns {boolean}
     */
    isMultiplayerConnected() {
        return this.isConnected;
    }

    /**
     * Check if current user is host
     * @returns {boolean}
     */
    isCurrentUserHost() {
        return this.isHost;
    }

    /**
     * Add event listener (deprecated - use eventBus instead)
     * @param {string} event 
     * @param {Function} callback 
     * @deprecated Use eventBus.addEventListener instead
     */
    addEventListener(event, callback) {
        console.warn('MultiplayerManager.addEventListener is deprecated. Use eventBus.addEventListener instead.');
        if (!this.eventListeners.has(event)) {
            this.eventListeners.set(event, []);
        }
        this.eventListeners.get(event).push(callback);
    }