/**
 * BossAISystem.js
 * Manages boss enemy AI, behavior patterns, and special abilities
 * for the tower defense game
 */

export class BossAISystem {
    constructor({ healthSystem, statusEffectSystem, projectileSystem, eventBus }) {
        // Dependency injection - store only what we need
        this.healthSystem = healthSystem;
        this.statusEffectSystem = statusEffectSystem;
        this.projectileSystem = projectileSystem;
        this.eventBus = eventBus;
        
        this.bosses = new Map(); // bossId -> bossData
        this.behaviorStates = new Map(); // bossId -> currentState
        this.eventListeners = new Map();
        
        this.initializeBossTypes();
    }

    /**
     * Initialize boss types and their configurations
     */
    initializeBossTypes() {
        this.bossTypes = {
            tank_boss: {
                name: 'Iron Golem',
                health: 5000,
                armor: 50,
                speed: 20,
                size: 40,
                reward: 500,
                abilities: ['charge', 'armor_boost', 'stomp'],
                phases: [
                    { healthThreshold: 1.0, behavior: 'aggressive' },
                    { healthThreshold: 0.6, behavior: 'defensive' },
                    { healthThreshold: 0.3, behavior: 'berserk' }
                ],
                immunities: ['slow', 'freeze'],
                sprite: 'boss_tank'
            },
            wizard_boss: {
                name: 'Arcane Master',
                health: 3000,
                armor: 20,
                magicResistance: 80,
                speed: 30,
                size: 35,
                reward: 750,
                abilities: ['teleport', 'magic_shield', 'summon_minions', 'meteor'],
                phases: [
                    { healthThreshold: 1.0, behavior: 'cautious' },
                    { healthThreshold: 0.7, behavior: 'aggressive' },
                    { healthThreshold: 0.4, behavior: 'desperate' }
                ],
                immunities: ['poison'],
                sprite: 'boss_wizard'
            },
            speed_boss: {
                name: 'Shadow Runner',
                health: 2500,
                armor: 10,
                speed: 80,
                size: 30,
                reward: 600,
                abilities: ['dash', 'clone', 'stealth', 'speed_boost'],
                phases: [
                    { healthThreshold: 1.0, behavior: 'evasive' },
                    { healthThreshold: 0.5, behavior: 'aggressive' },
                    { healthThreshold: 0.2, behavior: 'desperate' }
                ],
                immunities: [],
                sprite: 'boss_speed'
            },
            necromancer_boss: {
                name: 'Death Lord',
                health: 4000,
                armor: 30,
                magicResistance: 60,
                speed: 25,
                size: 38,
                reward: 800,
                abilities: ['raise_dead', 'life_drain', 'curse', 'death_aura'],
                phases: [
                    { healthThreshold: 1.0, behavior: 'summoner' },
                    { healthThreshold: 0.6, behavior: 'aggressive' },
                    { healthThreshold: 0.3, behavior: 'desperate' }
                ],
                immunities: ['poison', 'life_drain'],
                sprite: 'boss_necromancer'
            },
            dragon_boss: {
                name: 'Ancient Wyrm',
                health: 8000,
                armor: 40,
                magicResistance: 40,
                speed: 35,
                size: 50,
                reward: 1200,
                abilities: ['fire_breath', 'wing_buffet', 'aerial_strike', 'rage'],
                phases: [
                    { healthThreshold: 1.0, behavior: 'territorial' },
                    { healthThreshold: 0.7, behavior: 'aggressive' },
                    { healthThreshold: 0.4, behavior: 'aerial' },
                    { healthThreshold: 0.2, behavior: 'berserk' }
                ],
                immunities: ['burn'],
                sprite: 'boss_dragon'
            }
        };
    }

    /**
     * Spawn a boss enemy
     * @param {string} bossType 
     * @param {number} x 
     * @param {number} y 
     * @param {Object} options 
     * @returns {string} Boss ID
     */
    spawnBoss(bossType, x, y, options = {}) {
        const config = this.bossTypes[bossType];
        if (!config) {
            console.warn(`Unknown boss type: ${bossType}`);
            return null;
        }

        const bossId = `boss_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const boss = {
            id: bossId,
            type: bossType,
            name: config.name,
            x,
            y,
            startX: x,
            startY: y,
            
            // Stats
            maxHealth: config.health,
            currentHealth: config.health,
            armor: config.armor,
            magicResistance: config.magicResistance || 0,
            speed: config.speed,
            originalSpeed: config.speed,
            size: config.size,
            reward: config.reward,
            
            // AI State
            currentPhase: 0,
            behavior: config.phases[0].behavior,
            lastAbilityTime: 0,
            abilityQueue: [],
            target: null,
            
            // Movement
            path: options.path || [],
            pathIndex: 0,
            velocityX: 0,
            velocityY: 0,
            
            // Abilities
            abilities: [...config.abilities],
            abilityCooldowns: new Map(),
            immunities: new Set(config.immunities),
            
            // Visual
            sprite: config.sprite,
            facing: 1, // 1 for right, -1 for left
            animationFrame: 0,
            animationTime: 0,
            
            // State
            isAlive: true,
            isActive: true,
            spawnTime: Date.now(),
            
            // Special states
            isCharging: false,
            isStealthed: false,
            isFlying: false,
            minions: [],
            
            config
        };

        this.bosses.set(bossId, boss);
        this.behaviorStates.set(bossId, {
            state: 'spawning',
            stateTime: 0,
            lastStateChange: Date.now()
        });

        // Register with health system
        if (this.healthSystem) {
            this.healthSystem.registerEntity(bossId, {
                maxHealth: boss.maxHealth,
                currentHealth: boss.currentHealth,
                armor: boss.armor,
                magicResistance: boss.magicResistance,
                entityType: 'boss'
            });
        }

        this.emitEvent('bossSpawned', {
            bossId,
            boss,
            type: bossType
        });

        return bossId;
    }

    /**
     * Update boss AI system
     * @param {number} deltaTime 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    update(deltaTime, towers = [], enemies = []) {
        this.bosses.forEach((boss, bossId) => {
            if (!boss.isAlive || !boss.isActive) return;

            // Update boss AI
            this.updateBossAI(boss, deltaTime, towers, enemies);
            
            // Update boss movement
            this.updateBossMovement(boss, deltaTime);
            
            // Update boss abilities
            this.updateBossAbilities(boss, deltaTime);
            
            // Update boss phase
            this.updateBossPhase(boss);
            
            // Update animation
            this.updateBossAnimation(boss, deltaTime);
        });
    }

    /**
     * Update boss AI behavior
     * @param {Object} boss 
     * @param {number} deltaTime 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    updateBossAI(boss, deltaTime, towers, enemies) {
        const behaviorState = this.behaviorStates.get(boss.id);
        if (!behaviorState) return;

        behaviorState.stateTime += deltaTime;

        switch (boss.behavior) {
            case 'aggressive':
                this.handleAggressiveBehavior(boss, towers, enemies);
                break;
            case 'defensive':
                this.handleDefensiveBehavior(boss, towers, enemies);
                break;
            case 'evasive':
                this.handleEvasiveBehavior(boss, towers, enemies);
                break;
            case 'summoner':
                this.handleSummonerBehavior(boss, towers, enemies);
                break;
            case 'cautious':
                this.handleCautiousBehavior(boss, towers, enemies);
                break;
            case 'berserk':
                this.handleBerserkBehavior(boss, towers, enemies);
                break;
            case 'territorial':
                this.handleTerritorialBehavior(boss, towers, enemies);
                break;
            case 'aerial':
                this.handleAerialBehavior(boss, towers, enemies);
                break;
            case 'desperate':
                this.handleDesperateBehavior(boss, towers, enemies);
                break;
        }
    }

    /**
     * Handle aggressive behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleAggressiveBehavior(boss, towers, enemies) {
        // Target closest tower
        const closestTower = this.findClosestTower(boss, towers);
        if (closestTower) {
            boss.target = closestTower;
            this.moveTowardsTarget(boss, closestTower);
            
            // Use offensive abilities more frequently
            if (this.shouldUseAbility(boss, 0.3)) {
                this.queueOffensiveAbility(boss);
            }
        }
    }

    /**
     * Handle defensive behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleDefensiveBehavior(boss, towers, enemies) {
        // Use defensive abilities
        if (this.shouldUseAbility(boss, 0.4)) {
            this.queueDefensiveAbility(boss);
        }
        
        // Move more cautiously
        if (boss.target) {
            this.moveTowardsTarget(boss, boss.target, 0.5);
        }
    }

    /**
     * Handle evasive behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleEvasiveBehavior(boss, towers, enemies) {
        // Avoid tower ranges
        const threateningTowers = this.findThreateningTowers(boss, towers);
        if (threateningTowers.length > 0) {
            this.evadeTowers(boss, threateningTowers);
        }
        
        // Use mobility abilities
        if (this.shouldUseAbility(boss, 0.2)) {
            this.queueMobilityAbility(boss);
        }
    }

    /**
     * Handle summoner behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleSummonerBehavior(boss, towers, enemies) {
        // Summon minions regularly
        if (this.shouldUseAbility(boss, 0.5) && boss.minions.length < 5) {
            this.queueSummonAbility(boss);
        }
        
        // Stay back and let minions attack
        const safestPosition = this.findSafestPosition(boss, towers);
        if (safestPosition) {
            this.moveTowardsTarget(boss, safestPosition, 0.3);
        }
    }

    /**
     * Handle cautious behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleCautiousBehavior(boss, towers, enemies) {
        // Move slowly and use abilities strategically
        if (boss.target) {
            this.moveTowardsTarget(boss, boss.target, 0.7);
        }
        
        if (this.shouldUseAbility(boss, 0.6)) {
            this.queueStrategicAbility(boss);
        }
    }

    /**
     * Handle berserk behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleBerserkBehavior(boss, towers, enemies) {
        // Increase speed and use abilities rapidly
        boss.speed = boss.originalSpeed * 1.5;
        
        if (this.shouldUseAbility(boss, 0.1)) {
            this.queueRandomAbility(boss);
        }
        
        // Attack everything in range
        const nearbyTowers = this.findNearbyTowers(boss, towers, 100);
        nearbyTowers.forEach(tower => {
            this.attackTower(boss, tower);
        });
    }

    /**
     * Handle territorial behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleTerritorialBehavior(boss, towers, enemies) {
        // Patrol area and attack intruders
        const distanceFromStart = this.getDistance(boss.x, boss.y, boss.startX, boss.startY);
        
        if (distanceFromStart > 150) {
            // Return to territory
            this.moveTowardsTarget(boss, { x: boss.startX, y: boss.startY });
        } else {
            // Attack nearby towers
            const nearbyTowers = this.findNearbyTowers(boss, towers, 120);
            if (nearbyTowers.length > 0) {
                boss.target = nearbyTowers[0];
                this.moveTowardsTarget(boss, boss.target);
            }
        }
    }

    /**
     * Handle aerial behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleAerialBehavior(boss, towers, enemies) {
        boss.isFlying = true;
        
        // Fly over towers and attack from above
        if (this.shouldUseAbility(boss, 0.3)) {
            this.queueAerialAbility(boss);
        }
        
        // Move in swooping patterns
        this.performAerialMovement(boss, towers);
    }

    /**
     * Handle desperate behavior
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {Array} enemies 
     */
    handleDesperateBehavior(boss, towers, enemies) {
        // Use all abilities rapidly
        if (this.shouldUseAbility(boss, 0.05)) {
            this.queueDesperateAbility(boss);
        }
        
        // Ignore defense, go all-out attack
        const allTowers = towers.filter(t => t.isAlive);
        if (allTowers.length > 0) {
            const randomTower = allTowers[Math.floor(Math.random() * allTowers.length)];
            boss.target = randomTower;
            this.moveTowardsTarget(boss, randomTower, 1.5);
        }
    }

    /**
     * Update boss movement
     * @param {Object} boss 
     * @param {number} deltaTime 
     */
    updateBossMovement(boss, deltaTime) {
        // Apply velocity
        boss.x += boss.velocityX * deltaTime;
        boss.y += boss.velocityY * deltaTime;
        
        // Update facing direction
        if (boss.velocityX > 0) boss.facing = 1;
        else if (boss.velocityX < 0) boss.facing = -1;
        
        // Apply friction
        boss.velocityX *= 0.9;
        boss.velocityY *= 0.9;
    }

    /**
     * Update boss abilities
     * @param {Object} boss 
     * @param {number} deltaTime 
     */
    updateBossAbilities(boss, deltaTime) {
        const currentTime = Date.now();
        
        // Update cooldowns
        boss.abilityCooldowns.forEach((cooldownEnd, ability) => {
            if (currentTime >= cooldownEnd) {
                boss.abilityCooldowns.delete(ability);
            }
        });
        
        // Execute queued abilities
        if (boss.abilityQueue.length > 0 && currentTime - boss.lastAbilityTime > 1000) {
            const ability = boss.abilityQueue.shift();
            this.executeAbility(boss, ability);
            boss.lastAbilityTime = currentTime;
        }
    }

    /**
     * Update boss phase based on health
     * @param {Object} boss 
     */
    updateBossPhase(boss) {
        const healthPercentage = boss.currentHealth / boss.maxHealth;
        const phases = boss.config.phases;
        
        for (let i = phases.length - 1; i >= 0; i--) {
            if (healthPercentage <= phases[i].healthThreshold) {
                if (boss.currentPhase !== i) {
                    boss.currentPhase = i;
                    boss.behavior = phases[i].behavior;
                    
                    this.emitEvent('bossPhaseChanged', {
                        bossId: boss.id,
                        phase: i,
                        behavior: boss.behavior,
                        healthPercentage
                    });
                }
                break;
            }
        }
    }

    /**
     * Update boss animation
     * @param {Object} boss 
     * @param {number} deltaTime 
     */
    updateBossAnimation(boss, deltaTime) {
        boss.animationTime += deltaTime;
        
        // Simple frame animation
        if (boss.animationTime > 200) {
            boss.animationFrame = (boss.animationFrame + 1) % 4;
            boss.animationTime = 0;
        }
    }

    /**
     * Execute boss ability
     * @param {Object} boss 
     * @param {string} ability 
     */
    executeAbility(boss, ability) {
        if (boss.abilityCooldowns.has(ability)) return;
        
        const cooldownTime = this.getAbilityCooldown(ability);
        boss.abilityCooldowns.set(ability, Date.now() + cooldownTime);
        
        switch (ability) {
            case 'charge':
                this.executeCharge(boss);
                break;
            case 'teleport':
                this.executeTeleport(boss);
                break;
            case 'summon_minions':
                this.executeSummonMinions(boss);
                break;
            case 'fire_breath':
                this.executeFireBreath(boss);
                break;
            case 'stealth':
                this.executeStealth(boss);
                break;
            case 'armor_boost':
                this.executeArmorBoost(boss);
                break;
            case 'life_drain':
                this.executeLifeDrain(boss);
                break;
            case 'meteor':
                this.executeMeteor(boss);
                break;
            case 'dash':
                this.executeDash(boss);
                break;
            case 'wing_buffet':
                this.executeWingBuffet(boss);
                break;
            // Add more abilities as needed
        }
        
        this.emitEvent('bossAbilityUsed', {
            bossId: boss.id,
            ability,
            boss
        });
    }

    /**
     * Execute charge ability
     * @param {Object} boss 
     */
    executeCharge(boss) {
        if (boss.target) {
            const dx = boss.target.x - boss.x;
            const dy = boss.target.y - boss.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 0) {
                boss.velocityX = (dx / distance) * boss.speed * 3;
                boss.velocityY = (dy / distance) * boss.speed * 3;
                boss.isCharging = true;
                
                setTimeout(() => {
                    boss.isCharging = false;
                }, 1000);
            }
        }
    }

    /**
     * Execute teleport ability
     * @param {Object} boss 
     */
    executeTeleport(boss) {
        // Teleport to random nearby location
        const angle = Math.random() * Math.PI * 2;
        const distance = 100 + Math.random() * 100;
        
        boss.x += Math.cos(angle) * distance;
        boss.y += Math.sin(angle) * distance;
        
        // Create visual effect
        this.emitEvent('bossEffect', {
            bossId: boss.id,
            effect: 'teleport',
            x: boss.x,
            y: boss.y
        });
    }

    /**
     * Execute summon minions ability
     * @param {Object} boss 
     */
    executeSummonMinions(boss) {
        const minionCount = 2 + Math.floor(Math.random() * 3);
        
        for (let i = 0; i < minionCount; i++) {
            const angle = (Math.PI * 2 * i) / minionCount;
            const distance = 50;
            
            const minionX = boss.x + Math.cos(angle) * distance;
            const minionY = boss.y + Math.sin(angle) * distance;
            
            const minion = {
                id: `minion_${Date.now()}_${i}`,
                x: minionX,
                y: minionY,
                health: 100,
                speed: 40,
                damage: 20,
                boss: boss.id
            };
            
            boss.minions.push(minion);
            
            this.emitEvent('minionSummoned', {
                bossId: boss.id,
                minion
            });
        }
    }

    /**
     * Execute fire breath ability
     * @param {Object} boss 
     */
    executeFireBreath(boss) {
        if (boss.target) {
            const angle = Math.atan2(boss.target.y - boss.y, boss.target.x - boss.x);
            
            // Create fire breath effect
            this.emitEvent('bossEffect', {
                bossId: boss.id,
                effect: 'fire_breath',
                x: boss.x,
                y: boss.y,
                angle,
                damage: 150,
                range: 200
            });
        }
    }

    /**
     * Execute stealth ability
     * @param {Object} boss 
     */
    executeStealth(boss) {
        boss.isStealthed = true;
        boss.speed *= 1.5;
        
        setTimeout(() => {
            boss.isStealthed = false;
            boss.speed = boss.originalSpeed;
        }, 3000);
    }

    /**
     * Execute armor boost ability
     * @param {Object} boss 
     */
    executeArmorBoost(boss) {
        if (this.statusEffectSystem) {
            this.statusEffectSystem.applyEffect(boss.id, 'armor_boost', {
                duration: 10000,
                armorBoost: 30
            });
        }
    }

    /**
     * Execute life drain ability
     * @param {Object} boss 
     */
    executeLifeDrain(boss) {
        // Drain health from nearby enemies and heal self
        const drainAmount = 50;
        
        if (this.healthSystem) {
            this.healthSystem.heal(boss.id, drainAmount, {
                healType: 'life_drain',
                source: boss.id
            });
        }
    }

    /**
     * Execute meteor ability
     * @param {Object} boss 
     */
    executeMeteor(boss) {
        if (boss.target) {
            // Delayed meteor strike
            setTimeout(() => {
                this.emitEvent('bossEffect', {
                    bossId: boss.id,
                    effect: 'meteor',
                    x: boss.target.x,
                    y: boss.target.y,
                    damage: 200,
                    radius: 80
                });
            }, 2000);
        }
    }

    /**
     * Execute dash ability
     * @param {Object} boss 
     */
    executeDash(boss) {
        if (boss.target) {
            const dx = boss.target.x - boss.x;
            const dy = boss.target.y - boss.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 0) {
                boss.velocityX = (dx / distance) * boss.speed * 4;
                boss.velocityY = (dy / distance) * boss.speed * 4;
            }
        }
    }

    /**
     * Execute wing buffet ability
     * @param {Object} boss 
     */
    executeWingBuffet(boss) {
        // Knockback nearby enemies and create wind effect
        this.emitEvent('bossEffect', {
            bossId: boss.id,
            effect: 'wing_buffet',
            x: boss.x,
            y: boss.y,
            radius: 120,
            knockback: 100
        });
    }

    // Utility methods

    /**
     * Find closest tower to boss
     * @param {Object} boss 
     * @param {Array} towers 
     * @returns {Object|null}
     */
    findClosestTower(boss, towers) {
        let closest = null;
        let closestDistance = Infinity;
        
        towers.forEach(tower => {
            if (!tower.isAlive) return;
            
            const distance = this.getDistance(boss.x, boss.y, tower.x, tower.y);
            if (distance < closestDistance) {
                closestDistance = distance;
                closest = tower;
            }
        });
        
        return closest;
    }

    /**
     * Find threatening towers (in range of boss)
     * @param {Object} boss 
     * @param {Array} towers 
     * @returns {Array}
     */
    findThreateningTowers(boss, towers) {
        return towers.filter(tower => {
            if (!tower.isAlive) return false;
            
            const distance = this.getDistance(boss.x, boss.y, tower.x, tower.y);
            return distance <= tower.range;
        });
    }

    /**
     * Find nearby towers within radius
     * @param {Object} boss 
     * @param {Array} towers 
     * @param {number} radius 
     * @returns {Array}
     */
    findNearbyTowers(boss, towers, radius) {
        return towers.filter(tower => {
            if (!tower.isAlive) return false;
            
            const distance = this.getDistance(boss.x, boss.y, tower.x, tower.y);
            return distance <= radius;
        });
    }

    /**
     * Move boss towards target
     * @param {Object} boss 
     * @param {Object} target 
     * @param {number} speedMultiplier 
     */
    moveTowardsTarget(boss, target, speedMultiplier = 1.0) {
        const dx = target.x - boss.x;
        const dy = target.y - boss.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance > 0) {
            const speed = boss.speed * speedMultiplier;
            boss.velocityX += (dx / distance) * speed * 0.1;
            boss.velocityY += (dy / distance) * speed * 0.1;
        }
    }

    /**
     * Check if boss should use ability
     * @param {Object} boss 
     * @param {number} probability 
     * @returns {boolean}
     */
    shouldUseAbility(boss, probability) {
        return Math.random() < probability && boss.abilityQueue.length < 3;
    }

    /**
     * Queue offensive ability
     * @param {Object} boss 
     */
    queueOffensiveAbility(boss) {
        const offensiveAbilities = boss.abilities.filter(ability => 
            ['charge', 'fire_breath', 'meteor', 'dash'].includes(ability)
        );
        
        if (offensiveAbilities.length > 0) {
            const ability = offensiveAbilities[Math.floor(Math.random() * offensiveAbilities.length)];
            boss.abilityQueue.push(ability);
        }
    }

    /**
     * Queue defensive ability
     * @param {Object} boss 
     */
    queueDefensiveAbility(boss) {
        const defensiveAbilities = boss.abilities.filter(ability => 
            ['armor_boost', 'magic_shield', 'stealth'].includes(ability)
        );
        
        if (defensiveAbilities.length > 0) {
            const ability = defensiveAbilities[Math.floor(Math.random() * defensiveAbilities.length)];
            boss.abilityQueue.push(ability);
        }
    }

    /**
     * Queue mobility ability
     * @param {Object} boss 
     */
    queueMobilityAbility(boss) {
        const mobilityAbilities = boss.abilities.filter(ability => 
            ['teleport', 'dash', 'speed_boost'].includes(ability)
        );
        
        if (mobilityAbilities.length > 0) {
            const ability = mobilityAbilities[Math.floor(Math.random() * mobilityAbilities.length)];
            boss.abilityQueue.push(ability);
        }
    }

    /**
     * Queue summon ability
     * @param {Object} boss 
     */
    queueSummonAbility(boss) {
        if (boss.abilities.includes('summon_minions')) {
            boss.abilityQueue.push('summon_minions');
        }
    }

    /**
     * Queue strategic ability
     * @param {Object} boss 
     */
    queueStrategicAbility(boss) {
        // Add strategic ability queuing logic
        this.queueRandomAbility(boss);
    }

    /**
     * Queue aerial ability
     * @param