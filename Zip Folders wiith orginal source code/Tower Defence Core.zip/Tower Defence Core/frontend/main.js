// Main Game Entry Point - Refactored with ES6 Modules and Dependency Injection
import * as THREE from 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
import { GameLoop } from './GameLoop.js';
import { ResourceManager } from './ResourceManager.js';
import { PlayerHealthSystem } from './PlayerHealthSystem.js';
import { AudioManager } from './AudioManager.js';
import { InputManager } from './InputManager.js';
import { NotificationManager } from './NotificationManager.js';
import { HUDManager } from './HUDManager.js';
import { EnemyUIManager } from './EnemyUIManager.js';
import { MapData } from './MapData.js';
import { LevelData } from './LevelData.js';
import { Pathfinding } from './Pathfinding.js';
import { EnemyFactory } from './enemy.js';
import { WaveManager } from './WaveManager.js';
import { TowerFactory } from './tower.js';

// Import additional systems that should be moved to separate modules
// Note: These classes should ideally be in separate files
class TowerSystem {
    constructor({ scene, resourceManager, notificationManager, audioManager }) {
        this.scene = scene;
        this.resourceManager = resourceManager;
        this.notificationManager = notificationManager;
        this.audioManager = audioManager;
        this.towers = [];
    }
    
    update(deltaTime) {
        this.towers.forEach(tower => tower.update(deltaTime));
    }
    
    addTower(tower) {
        this.towers.push(tower);
        this.scene.add(tower.mesh);
    }
    
    getTowers() {
        return this.towers;
    }
}

class TargetingSystem {
    constructor({ getEnemies, getTowers }) {
        this.getEnemies = getEnemies;
        this.getTowers = getTowers;
    }
    
    update(deltaTime) {
        const enemies = this.getEnemies();
        const towers = this.getTowers();
        
        towers.forEach(tower => {
            if (tower.canFire()) {
                const target = this.findBestTarget(tower, enemies);
                if (target) {
                    tower.setTarget(target);
                }
            }
        });
    }
    
    findBestTarget(tower, enemies) {
        let bestTarget = null;
        let bestDistance = Infinity;
        
        enemies.forEach(enemy => {
            const distance = tower.position.distanceTo(enemy.position);
            if (distance <= tower.range && distance < bestDistance) {
                bestTarget = enemy;
                bestDistance = distance;
            }
        });
        
        return bestTarget;
    }
}

class ProjectileSystem {
    constructor({ scene, audioManager }) {
        this.scene = scene;
        this.audioManager = audioManager;
        this.projectiles = [];
    }
    
    update(deltaTime) {
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const projectile = this.projectiles[i];
            projectile.update(deltaTime);
            
            if (projectile.shouldRemove) {
                this.scene.remove(projectile.mesh);
                this.projectiles.splice(i, 1);
            }
        }
    }
    
    addProjectile(projectile) {
        this.projectiles.push(projectile);
        this.scene.add(projectile.mesh);
    }
    
    getProjectiles() {
        return this.projectiles;
    }
}

class StatusEffectSystem {
    constructor() {
        this.activeEffects = new Map();
    }
    
    update(deltaTime) {
        this.activeEffects.forEach((effects, entity) => {
            effects.forEach((effect, index) => {
                effect.update(deltaTime);
                if (effect.isExpired()) {
                    effects.splice(index, 1);
                }
            });
            
            if (effects.length === 0) {
                this.activeEffects.delete(entity);
            }
        });
    }
}

class HealthSystem {
    constructor({ notificationManager, resourceManager }) {
        this.notificationManager = notificationManager;
        this.resourceManager = resourceManager;
    }
    
    update(deltaTime) {
        // Handle health regeneration, damage over time, etc.
    }
    
    takeDamage(entity, damage) {
        entity.health -= damage;
        if (entity.health <= 0) {
            entity.isDead = true;
            this.onEntityDeath(entity);
        }
    }
    
    onEntityDeath(entity) {
        if (entity.bounty) {
            this.resourceManager.addGold(entity.bounty);
        }
    }
}

class BossAISystem {
    constructor({ getEnemies, notificationManager }) {
        this.getEnemies = getEnemies;
        this.notificationManager = notificationManager;
    }
    
    update(deltaTime) {
        const enemies = this.getEnemies();
        const bosses = enemies.filter(enemy => enemy.isBoss);
        
        bosses.forEach(boss => {
            this.updateBossAI(boss, deltaTime);
        });
    }
    
    updateBossAI(boss, deltaTime) {
        // Implement boss-specific AI logic
    }
}

class ParticleSystem {
    constructor({ scene }) {
        this.scene = scene;
        this.particles = [];
    }
    
    update(deltaTime) {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            particle.update(deltaTime);
            
            if (particle.isDead) {
                this.scene.remove(particle.mesh);
                this.particles.splice(i, 1);
            }
        }
    }
    
    createExplosion(position, type) {
        // Create explosion particles at position
        console.log(`Creating ${type} explosion at`, position);
    }
}

class VisualFeedbackSystem {
    constructor({ scene, notificationManager }) {
        this.scene = scene;
        this.notificationManager = notificationManager;
        this.feedbackElements = [];
    }
    
    update(deltaTime) {
        this.feedbackElements.forEach((element, index) => {
            element.update(deltaTime);
            if (element.isComplete) {
                this.scene.remove(element.mesh);
                this.feedbackElements.splice(index, 1);
            }
        });
    }
}

class TowerStoreUI {
    constructor({ resourceManager, notificationManager, onTowerPurchase }) {
        this.resourceManager = resourceManager;
        this.notificationManager = notificationManager;
        this.onTowerPurchase = onTowerPurchase;
        this.setupUI();
    }
    
    setupUI() {
        // Setup tower store UI elements
        console.log('Tower store UI initialized');
    }
}

class Game {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.canvas = null;
        
        // Game Systems - will be initialized in initGameSystems()
        this.gameLoop = null;
        this.resourceManager = null;
        this.playerHealthSystem = null;
        this.audioManager = null;
        this.inputManager = null;
        this.notificationManager = null;
        this.hudManager = null; // Fixed: Initialize as null instead of calling constructor prematurely
        this.enemyUIManager = null;
        this.waveManager = null;
        this.towerSystem = null;
        this.targetingSystem = null;
        this.projectileSystem = null;
        this.healthSystem = null;
        this.statusEffectSystem = null;
        this.bossAISystem = null;
        this.particleSystem = null;
        this.visualFeedbackSystem = null;
        this.towerStoreUI = null;
        this.pathfinding = null;
        
        // Game State
        this.gameState = 'loading'; // loading, playing, paused, gameOver
        this.currentLevel = 1;
        this.gameSpeed = 1;
        this.isPaused = false;
        
        // Game Objects - managed by systems but accessible for queries
        this.enemies = [];
        this.towers = [];
        this.projectiles = [];
        this.particles = [];
        
        // Map and Level Data
        this.mapData = null;
        this.levelData = null;
        this.enemyPath = [];
        
        // Performance Tracking
        this.lastFrameTime = 0;
        this.deltaTime = 0;
        this.fps = 0;
        this.frameCount = 0;
        
        // Initialize the game
        this.init();
    }
    
    async init() {
        try {
            console.log('Initializing AI-Powered 3D Tower Defense Game...');
            
            // Initialize Three.js
            await this.initThreeJS();
            
            // Initialize game systems with dependency injection
            await this.initGameSystems();
            
            // Load game data
            await this.loadGameData();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Hide loading screen and start game
            this.hideLoadingScreen();
            
            // Start the game loop
            this.startGame();
            
            console.log('Game initialized successfully!');
            
        } catch (error) {
            console.error('Failed to initialize game:', error);
            this.showError('Failed to initialize game. Please refresh the page.');
        }
    }
    
    async initThreeJS() {
        // Get canvas element
        this.canvas = document.getElementById('gameCanvas');
        if (!this.canvas) {
            throw new Error('Game canvas not found');
        }
        
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB); // Sky blue background
        
        // Create camera
        const aspect = this.canvas.width / this.canvas.height;
        this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
        this.camera.position.set(0, 20, 15);
        this.camera.lookAt(0, 0, 0);
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({ 
            canvas: this.canvas, 
            antialias: true 
        });
        this.renderer.setSize(this.canvas.width, this.canvas.height);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        
        // Add lights
        this.setupLighting();
        
        // Add basic ground plane
        this.createGround();
        
        console.log('Three.js initialized');
    }
    
    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
        this.scene.add(ambientLight);
        
        // Directional light (sun)
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 20, 5);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -20;
        directionalLight.shadow.camera.right = 20;
        directionalLight.shadow.camera.top = 20;
        directionalLight.shadow.camera.bottom = -20;
        this.scene.add(directionalLight);
        
        // Point light for dynamic lighting
        const pointLight = new THREE.PointLight(0xff6600, 0.5, 30);
        pointLight.position.set(0, 10, 0);
        this.scene.add(pointLight);
    }
    
    createGround() {
        // Create ground geometry
        const groundGeometry = new THREE.PlaneGeometry(40, 30);
        const groundMaterial = new THREE.MeshLambertMaterial({ 
            color: 0x228B22,
            transparent: true,
            opacity: 0.8
        });
        
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);
        
        // Add grid helper
        const gridHelper = new THREE.GridHelper(40, 40, 0x444444, 0x444444);
        gridHelper.material.opacity = 0.3;
        gridHelper.material.transparent = true;
        this.scene.add(gridHelper);
    }
    
    async initGameSystems() {
        console.log('Initializing game systems with dependency injection...');
        
        // Initialize core systems first (no dependencies)
        this.notificationManager = new NotificationManager();
        this.audioManager = new AudioManager();
        await this.audioManager.init(); // Wait for audio to be ready
        
        this.resourceManager = new ResourceManager({
            notificationManager: this.notificationManager
        });
        
        this.playerHealthSystem = new PlayerHealthSystem({
            initialLives: 3,
            notificationManager: this.notificationManager
        });
        
        // Initialize systems that depend on core systems
        this.particleSystem = new ParticleSystem({
            scene: this.scene
        });
        
        this.healthSystem = new HealthSystem({
            notificationManager: this.notificationManager,
            resourceManager: this.resourceManager
        });
        
        this.statusEffectSystem = new StatusEffectSystem();
        
        this.projectileSystem = new ProjectileSystem({
            scene: this.scene,
            audioManager: this.audioManager
        });
        
        this.towerSystem = new TowerSystem({
            scene: this.scene,
            resourceManager: this.resourceManager,
            notificationManager: this.notificationManager,
            audioManager: this.audioManager
        });
        
        // Initialize systems that need game object queries
        this.targetingSystem = new TargetingSystem({
            getEnemies: () => this.getEnemies(),
            getTowers: () => this.getTowers()
        });
        
        this.bossAISystem = new BossAISystem({
            getEnemies: () => this.getEnemies(),
            notificationManager: this.notificationManager
        });
        
        this.visualFeedbackSystem = new VisualFeedbackSystem({
            scene: this.scene,
            notificationManager: this.notificationManager
        });
        
        // Initialize input manager with game callbacks
        this.inputManager = new InputManager({
            onTowerPlace: (position) => this.onTowerPlace(position),
            onPause: () => this.togglePause(),
            onSpeedChange: () => this.toggleSpeed()
        });
        
        // Initialize UI systems - Note: HUD manager will be properly initialized after wave manager
        this.enemyUIManager = new EnemyUIManager({
            getEnemies: () => this.getEnemies()
        });
        
        this.towerStoreUI = new TowerStoreUI({
            resourceManager: this.resourceManager,
            notificationManager: this.notificationManager,
            onTowerPurchase: (towerType) => this.onTowerPurchase(towerType)
        });
        
        // Initialize pathfinding
        this.pathfinding = new Pathfinding();
        
        console.log('Core game systems initialized');
    }
    
    async loadGameData() {
        console.log('Loading game data...');
        
        // Load map data
        this.mapData = new MapData();
        await this.mapData.loadLevel(this.currentLevel);
        
        // Load level data
        this.levelData = new LevelData();
        await this.levelData.loadLevel(this.currentLevel);
        
        // Initialize pathfinding with map data
        this.pathfinding.initializeGrid(this.mapData);
        
        // Generate enemy path
        this.enemyPath = this.pathfinding.generatePath(
            this.mapData.getSpawnPoint(),
            this.mapData.getEndPoint(),
            this.mapData.getObstacles()
        );
        
        // Now initialize wave manager with all dependencies
        this.waveManager = new WaveManager({
            levelData: this.levelData,
            notificationManager: this.notificationManager,
            resourceManager: this.resourceManager,
            playerHealthSystem: this.playerHealthSystem,
            audioManager: this.audioManager,
            addEnemy: (enemy) => this.addEnemy(enemy),
            getEnemyPath: () => this.getEnemyPath()
        });
        
        // Now initialize HUD manager with all required dependencies
        this.hudManager = new HUDManager({
            resourceManager: this.resourceManager,
            playerHealthSystem: this.playerHealthSystem,
            waveManager: this.waveManager,
            getTowers: () => this.getTowers(),
            getEnemies: () => this.getEnemies(),
            getEnemyPath: () => this.getEnemyPath(),
            isPaused: () => this.isPaused,
            gameSpeed: () => this.gameSpeed
        });
        
        // Initialize game loop with all systems ready
        this.gameLoop = new GameLoop({
            update: (deltaTime) => this.update(deltaTime),
            render: () => this.render()
        });
        
        // Create path visualization
        this.visualizePath();
        
        console.log('Game data loaded');
    }
    
    visualizePath() {
        if (this.enemyPath.length < 2) return;
        
        // Create path line
        const pathGeometry = new THREE.BufferGeometry();
        const pathPoints = this.enemyPath.map(point => new THREE.Vector3(point.x, 0.1, point.z));
        pathGeometry.setFromPoints(pathPoints);
        
        const pathMaterial = new THREE.LineBasicMaterial({ 
            color: 0xff6600,
            linewidth: 3
        });
        
        const pathLine = new THREE.Line(pathGeometry, pathMaterial);
        this.scene.add(pathLine);
        
        // Add path markers
        this.enemyPath.forEach((point, index) => {
            if (index % 3 === 0) { // Every 3rd point
                const markerGeometry = new THREE.SphereGeometry(0.2, 8, 8);
                const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xff6600 });
                const marker = new THREE.Mesh(markerGeometry, markerMaterial);
                marker.position.set(point.x, 0.2, point.z);
                this.scene.add(marker);
            }
        });
    }
    
    setupEventListeners() {
        // Window resize
        window.addEventListener('resize', () => this.onWindowResize());
        
        // Delegate input handling to InputManager
        this.inputManager.setupEventListeners(this.canvas, document);
        
        // Game control buttons
        const pauseBtn = document.getElementById('pauseBtn');
        const speedBtn = document.getElementById('speedBtn');
        const nextWaveBtn = document.getElementById('nextWaveBtn');
        const startWaveBtn = document.getElementById('startWaveBtn'); // From HTML
        
        if (pauseBtn) pauseBtn.addEventListener('click', () => this.togglePause());
        if (speedBtn) speedBtn.addEventListener('click', () => this.toggleSpeed());
        if (nextWaveBtn) nextWaveBtn.addEventListener('click', () => this.startNextWave());
        if (startWaveBtn) startWaveBtn.addEventListener('click', () => this.startNextWave());
        
        console.log('Event listeners setup');
    }
    
    onWindowResize() {
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        
        this.renderer.setSize(width, height);
    }
    
    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
    }
    
    showError(message) {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.innerHTML = `
                <div style="color: #ff4444; text-align: center;">
                    <h2>Error</h2>
                    <p>${message}</p>
                    <button onclick="location.reload()" style="margin-top: 20px; padding: 10px 20px; background: #ff4444; color: white; border: none; border-radius: 5px; cursor: pointer;">
                        Reload Game
                    </button>
                </div>
            `;
        }
    }
    
    startGame() {
        this.gameState = 'playing';
        this.gameLoop.start();
        this.notificationManager.show('Game Started!', 2000);
        this.audioManager.playBackgroundMusic();
        
        // Start first wave after a delay
        setTimeout(() => {
            this.waveManager.startWave(1);
        }, 3000);
    }
    
    togglePause() {
        if (this.gameState === 'playing') {
            this.gameState = 'paused';
            this.isPaused = true;
            const pauseBtn = document.getElementById('pauseBtn');
            if (pauseBtn) pauseBtn.textContent = 'Resume';
            this.notificationManager.show('Game Paused', 1000);
        } else if (this.gameState === 'paused') {
            this.gameState = 'playing';
            this.isPaused = false;
            const pauseBtn = document.getElementById('pauseBtn');
            if (pauseBtn) pauseBtn.textContent = 'Pause';
            this.notificationManager.show('Game Resumed', 1000);
        }
    }
    
    toggleSpeed() {
        const speedBtn = document.getElementById('speedBtn');
        if (this.gameSpeed === 1) {
            this.gameSpeed = 2;
            if (speedBtn) speedBtn.textContent = 'Speed x2';
        } else if (this.gameSpeed === 2) {
            this.gameSpeed = 3;
            if (speedBtn) speedBtn.textContent = 'Speed x3';
        } else {
            this.gameSpeed = 1;
            if (speedBtn) speedBtn.textContent = 'Speed x1';
        }
        this.notificationManager.show(`Speed: ${this.gameSpeed}x`, 1000);
    }
    
    startNextWave() {
        if (this.waveManager && this.waveManager.canStartNextWave()) {
            this.waveManager.startNextWave();
        }
    }
    
    update(deltaTime) {
        if (this.isPaused) return;
        
        // Apply game speed
        const adjustedDeltaTime = deltaTime * this.gameSpeed;
        
        // Update all game systems in proper order
        if (this.waveManager) this.waveManager.update(adjustedDeltaTime);
        if (this.towerSystem) this.towerSystem.update(adjustedDeltaTime);
        if (this.targetingSystem) this.targetingSystem.update(adjustedDeltaTime);
        if (this.projectileSystem) this.projectileSystem.update(adjustedDeltaTime);
        if (this.healthSystem) this.healthSystem.update(adjustedDeltaTime);
        if (this.statusEffectSystem) this.statusEffectSystem.update(adjustedDeltaTime);
        if (this.bossAISystem) this.bossAISystem.update(adjustedDeltaTime);
        if (this.particleSystem) this.particleSystem.update(adjustedDeltaTime);
        if (this.visualFeedbackSystem) this.visualFeedbackSystem.update(adjustedDeltaTime);
        
        // Update enemies
        this.updateEnemies(adjustedDeltaTime);
        
        // Update UI
        if (this.hudManager) this.hudManager.update();
        if (this.enemyUIManager) this.enemyUIManager.update();
        
        // Check game over conditions
        this.checkGameOver();
    }
    
    updateEnemies(deltaTime) {
        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const enemy = this.enemies[i];
            
            if (enemy.isDead) {
                // Remove dead enemy
                this.scene.remove(enemy.mesh);
                this.enemies.splice(i, 1);
                
                // Award resources
                this.resourceManager.addGold(enemy.bounty);
                this.resourceManager.addScore(enemy.scoreValue || 10);
                
                // Create death effect
                this.particleSystem.createExplosion(enemy.position, enemy.type);
                this.audioManager.playSound('enemyDeath');
                
                continue;
            }
            
            if (enemy.reachedEnd) {
                // Enemy reached the end
                this.scene.remove(enemy.mesh);
                this.enemies.splice(i, 1);
                
                // Damage player
                this.playerHealthSystem.takeDamage(enemy.damage || 1);
                this.notificationManager.show('Enemy Reached Base!', 1500);
                this.audioManager.playSound('baseDamage');
                
                continue;
            }
            
            // Update enemy
            enemy.update(deltaTime, this.enemyPath);
        }
    }
    
    checkGameOver() {
        if (this.playerHealthSystem.isDead()) {
            this.gameOver();
        } else if (this.waveManager && this.waveManager.isAllWavesComplete() && this.enemies.length === 0) {
            this.victory();
        }
    }
    
    gameOver() {
        this.gameState = 'gameOver';
        if (this.gameLoop) this.gameLoop.stop();
        
        // Show game over screen
        this.notificationManager.show('GAME OVER', 5000);
        
        this.audioManager.stopBackgroundMusic();
        this.audioManager.playSound('gameOver');
    }
    
    victory() {
        this.gameState = 'victory';
        if (this.gameLoop) this.gameLoop.stop();
        
        this.notificationManager.show('VICTORY!', 5000);
        this.audioManager.playSound('victory');
        
        // TODO: Implement victory screen and level progression
        setTimeout(() => {
            this.nextLevel();
        }, 5000);
    }
    
    nextLevel() {
        this.currentLevel++;
        // TODO: Implement level progression
        this.notificationManager.show(`Level ${this.currentLevel}!`, 3000);
        this.restartGame();
    }
    
    restartGame() {
        location.reload();
    }
    
    render() {
        this.renderer.render(this.scene, this.camera);
    }
    
    // Event handlers for dependency injection
    onTowerPlace(position) {
        // Handle tower placement
        console.log('Tower place requested at:', position);
    }
    
    onTowerPurchase(towerType) {
        // Handle tower purchase
        console.log('Tower purchase requested:', towerType);
    }
    
    // Public methods for other systems (query methods)
    addEnemy(enemy) {
        this.enemies.push(enemy);
        this.scene.add(enemy.mesh);
    }
    
    addTower(tower) {
        this.towerSystem.addTower(tower);
    }
    
    addProjectile(projectile) {
        this.projectileSystem.addProjectile(projectile);
    }
    
    getEnemies() {
        return this.enemies;
    }
    
    getTowers() {
        return this.towerSystem ? this.towerSystem.getTowers() : [];
    }
    
    getProjectiles() {
        return this.projectileSystem ? this.projectileSystem.getProjectiles() : [];
    }
    
    getEnemyPath() {
        return this.enemyPath;
    }
    
    getScene() {
        return this.scene;
    }
    
    getCamera() {
        return this.camera;
    }
    
    getRenderer() {
        return this.renderer;
    }
}

// Initialize game when page loads
window.addEventListener('load', () => {
    const game = new Game();
    // Make it globally accessible for debugging only
    window.game = game;
});

// Global restart function for HTML buttons
window.restartGame = function() {
    location.reload();
};