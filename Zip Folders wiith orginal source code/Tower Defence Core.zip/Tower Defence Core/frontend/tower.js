// Tower System - Refactored for ES6 Modules

export class Tower {
    constructor(type, position, level = 1, dependencies = {}) {
        // Extract dependencies using dependency injection
        this.scene = dependencies.scene;
        this.audioManager = dependencies.audioManager;
        this.getEnemies = dependencies.getEnemies; // Function to get current enemies
        
        // Basic properties
        this.id = Date.now() + Math.random();
        this.type = type;
        this.level = level;
        this.position = new THREE.Vector3(position.x, 0, position.z);
        
        // Get tower template
        this.template = this.getTowerTemplate(type);
        this.applyTemplate();
        
        // Combat properties
        this.damage = this.baseDamage;
        this.range = this.baseRange;
        this.fireRate = this.baseFireRate; // shots per second
        this.lastFireTime = 0;
        this.accuracy = this.baseAccuracy || 0.9;
        
        // Targeting
        this.target = null;
        this.targetingMode = 'nearest'; // nearest, strongest, weakest, first, last
        this.canTargetFlying = this.template.canTargetFlying !== false;
        this.canTargetGround = this.template.canTargetGround !== false;
        
        // Visual properties
        this.mesh = null;
        this.rangeIndicator = null;
        this.isSelected = false;
        this.showRange = false;
        
        // Upgrade properties
        this.maxLevel = 5;
        this.upgradeCosts = this.calculateUpgradeCosts();
        
        // Special abilities
        this.abilities = this.template.abilities || [];
        this.abilityTimers = new Map();
        
        // Effects
        this.muzzleFlash = null;
        this.projectiles = [];
        
        // Statistics
        this.stats = {
            enemiesKilled: 0,
            damageDealt: 0,
            shotsFired: 0,
            shotsHit: 0,
            totalCost: this.template.cost
        };
        
        // Create visual representation
        this.createMesh();
        
        console.log(`Tower created: ${type} at (${position.x}, ${position.z})`);
    }
    
    getTowerTemplate(type) {
        const templates = {
            basic: {
                name: 'Basic Tower',
                cost: 50,
                damage: 25,
                range: 8,
                fireRate: 1.5,
                projectileSpeed: 15,
                projectileType: 'bullet',
                color: 0x4CAF50,
                size: 1,
                abilities: [],
                canTargetFlying: true,
                canTargetGround: true
            },
            
            laser: {
                name: 'Laser Tower',
                cost: 100,
                damage: 15,
                range: 12,
                fireRate: 3,
                projectileSpeed: Infinity, // Instant hit
                projectileType: 'laser',
                color: 0x2196F3,
                size: 1.2,
                abilities: ['piercing'],
                canTargetFlying: true,
                canTargetGround: true
            },
            
            missile: {
                name: 'Missile Tower',
                cost: 150,
                damage: 80,
                range: 15,
                fireRate: 0.8,
                projectileSpeed: 8,
                projectileType: 'missile',
                color: 0xFF5722,
                size: 1.5,
                abilities: ['splash_damage', 'homing'],
                canTargetFlying: true,
                canTargetGround: true,
                splashRadius: 3
            },
            
            freeze: {
                name: 'Freeze Tower',
                cost: 120,
                damage: 10,
                range: 10,
                fireRate: 2,
                projectileSpeed: 12,
                projectileType: 'ice',
                color: 0x00BCD4,
                size: 1.1,
                abilities: ['slow_effect'],
                canTargetFlying: true,
                canTargetGround: true,
                slowIntensity: 0.5,
                slowDuration: 3000
            },
            
            tesla: {
                name: 'Tesla Tower',
                cost: 200,
                damage: 40,
                range: 6,
                fireRate: 2.5,
                projectileSpeed: Infinity,
                projectileType: 'lightning',
                color: 0xFFEB3B,
                size: 1.3,
                abilities: ['chain_lightning', 'stun'],
                canTargetFlying: true,
                canTargetGround: true,
                chainTargets: 3,
                stunDuration: 1000
            },
            
            poison: {
                name: 'Poison Tower',
                cost: 130,
                damage: 20,
                range: 9,
                fireRate: 1.8,
                projectileSpeed: 10,
                projectileType: 'poison',
                color: 0x8BC34A,
                size: 1.1,
                abilities: ['poison_effect', 'area_denial'],
                canTargetFlying: false,
                canTargetGround: true,
                poisonDuration: 5000,
                poisonDamage: 5
            }
        };
        
        return templates[type] || templates.basic;
    }
    
    applyTemplate() {
        this.name = this.template.name;
        this.cost = this.template.cost;
        this.baseDamage = this.template.damage;
        this.baseRange = this.template.range;
        this.baseFireRate = this.template.fireRate;
        this.projectileSpeed = this.template.projectileSpeed;
        this.projectileType = this.template.projectileType;
        this.color = this.template.color;
        this.size = this.template.size;
        this.baseAccuracy = this.template.accuracy || 0.9;
    }
    
    createMesh() {
        // Create tower base
        const baseGeometry = new THREE.CylinderGeometry(this.size * 0.8, this.size, this.size * 0.5, 8);
        const baseMaterial = new THREE.MeshLambertMaterial({ color: this.color });
        const base = new THREE.Mesh(baseGeometry, baseMaterial);
        base.position.y = this.size * 0.25;
        
        // Create tower turret
        const turretGeometry = new THREE.BoxGeometry(this.size * 0.6, this.size * 0.4, this.size * 1.2);
        const turretMaterial = new THREE.MeshLambertMaterial({ color: this.color });
        const turret = new THREE.Mesh(turretGeometry, turretMaterial);
        turret.position.y = this.size * 0.7;
        
        // Create barrel
        const barrelGeometry = new THREE.CylinderGeometry(0.1, 0.1, this.size * 0.8, 6);
        const barrelMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
        const barrel = new THREE.Mesh(barrelGeometry, barrelMaterial);
        barrel.rotation.z = Math.PI / 2;
        barrel.position.set(this.size * 0.6, 0, 0);
        turret.add(barrel);
        
        // Create tower group
        this.mesh = new THREE.Group();
        this.mesh.add(base);
        this.mesh.add(turret);
        this.mesh.position.copy(this.position);
        this.mesh.castShadow = true;
        this.mesh.receiveShadow = true;
        
        // Store references
        this.turret = turret;
        this.barrel = barrel;
        
        // Store reference to tower in mesh
        this.mesh.userData.tower = this;
        
        // Add special visual effects
        this.addSpecialEffects();
    }
    
    addSpecialEffects() {
        // Add glow effect for energy-based towers
        if (this.projectileType === 'laser' || this.projectileType === 'lightning') {
            const glowGeometry = new THREE.SphereGeometry(this.size * 1.2, 16, 16);
            const glowMaterial = new THREE.MeshBasicMaterial({
                color: this.color,
                transparent: true,
                opacity: 0.1,
                side: THREE.BackSide
            });
            
            this.glowEffect = new THREE.Mesh(glowGeometry, glowMaterial);
            this.glowEffect.position.y = this.size * 0.5;
            this.mesh.add(this.glowEffect);
        }
        
        // Add particle effects for special towers
        if (this.abilities.includes('poison_effect')) {
            this.createPoisonParticles();
        }
        
        if (this.abilities.includes('freeze_effect')) {
            this.createFreezeParticles();
        }
    }
    
    createPoisonParticles() {
        const particles = new THREE.Group();
        
        for (let i = 0; i < 12; i++) {
            const particleGeometry = new THREE.SphereGeometry(0.05, 4, 4);
            const particleMaterial = new THREE.MeshBasicMaterial({
                color: 0x44ff44,
                transparent: true,
                opacity: 0.6
            });
            
            const particle = new THREE.Mesh(particleGeometry, particleMaterial);
            particle.position.set(
                (Math.random() - 0.5) * this.size * 2,
                Math.random() * this.size * 2,
                (Math.random() - 0.5) * this.size * 2
            );
            
            particles.add(particle);
        }
        
        this.poisonParticles = particles;
        this.mesh.add(particles);
    }
    
    createFreezeParticles() {
        const particles = new THREE.Group();
        
        for (let i = 0; i < 8; i++) {
            const particleGeometry = new THREE.OctahedronGeometry(0.08, 0);
            const particleMaterial = new THREE.MeshBasicMaterial({
                color: 0x88ddff,
                transparent: true,
                opacity: 0.8
            });
            
            const particle = new THREE.Mesh(particleGeometry, particleMaterial);
            particle.position.set(
                (Math.random() - 0.5) * this.size * 1.5,
                Math.random() * this.size * 1.5,
                (Math.random() - 0.5) * this.size * 1.5
            );
            
            particles.add(particle);
        }
        
        this.freezeParticles = particles;
        this.mesh.add(particles);
    }
    
    update(deltaTime, enemies) {
        // Update targeting
        this.updateTargeting(enemies);
        
        // Update combat
        this.updateCombat(deltaTime);
        
        // Update abilities
        this.updateAbilities(deltaTime);
        
        // Update visual effects
        this.updateVisualEffects(deltaTime);
        
        // Update projectiles
        this.updateProjectiles(deltaTime, enemies);
    }
    
    updateTargeting(enemies) {
        // Clear target if it's dead or out of range
        if (this.target && (this.target.isDead || this.getDistanceToTarget() > this.range)) {
            this.target = null;
        }
        
        // Find new target if needed
        if (!this.target) {
            this.target = this.findBestTarget(enemies);
        }
        
        // Rotate turret towards target
        if (this.target && this.turret) {
            const targetPos = this.target.position.clone();
            const direction = targetPos.sub(this.position);
            const angle = Math.atan2(direction.x, direction.z);
            this.turret.rotation.y = angle;
        }
    }
    
    findBestTarget(enemies) {
        const validTargets = enemies.filter(enemy => {
            if (enemy.isDead) return false;
            
            const distance = this.position.distanceTo(enemy.position);
            if (distance > this.range) return false;
            
            if (enemy.isFlying && !this.canTargetFlying) return false;
            if (!enemy.isFlying && !this.canTargetGround) return false;
            
            return true;
        });
        
        if (validTargets.length === 0) return null;
        
        // Apply targeting mode
        switch (this.targetingMode) {
            case 'nearest':
                return this.findNearestTarget(validTargets);
            case 'strongest':
                return this.findStrongestTarget(validTargets);
            case 'weakest':
                return this.findWeakestTarget(validTargets);
            case 'first':
                return this.findFirstTarget(validTargets);
            case 'last':
                return this.findLastTarget(validTargets);
            default:
                return this.findNearestTarget(validTargets);
        }
    }
    
    findNearestTarget(targets) {
        let nearest = null;
        let minDistance = Infinity;
        
        targets.forEach(target => {
            const distance = this.position.distanceTo(target.position);
            if (distance < minDistance) {
                minDistance = distance;
                nearest = target;
            }
        });
        
        return nearest;
    }
    
    findStrongestTarget(targets) {
        return targets.reduce((strongest, target) => {
            return target.health > strongest.health ? target : strongest;
        });
    }
    
    findWeakestTarget(targets) {
        return targets.reduce((weakest, target) => {
            return target.health < weakest.health ? target : weakest;
        });
    }
    
    findFirstTarget(targets) {
        return targets.reduce((first, target) => {
            return target.getProgressAlongPath() > first.getProgressAlongPath() ? target : first;
        });
    }
    
    findLastTarget(targets) {
        return targets.reduce((last, target) => {
            return target.getProgressAlongPath() < last.getProgressAlongPath() ? target : last;
        });
    }
    
    updateCombat(deltaTime) {
        if (!this.target) return;
        
        const now = Date.now();
        const timeSinceLastShot = now - this.lastFireTime;
        const fireInterval = 1000 / this.fireRate; // Convert to milliseconds
        
        if (timeSinceLastShot >= fireInterval) {
            this.fire();
            this.lastFireTime = now;
        }
    }
    
    fire() {
        if (!this.target) return;
        
        // Calculate accuracy
        const hitChance = this.accuracy;
        const willHit = Math.random() < hitChance;
        
        // Create projectile
        const projectile = this.createProjectile(this.target, willHit);
        this.projectiles.push(projectile);
        
        // Update statistics
        this.stats.shotsFired++;
        if (willHit) {
            this.stats.shotsHit++;
        }
        
        // Visual effects
        this.triggerMuzzleFlash();
        this.triggerFireEffect();
        
        // Audio
        this.playFireSound();
        
        console.log(`${this.type} tower fired at ${this.target.type}`);
    }
    
    createProjectile(target, willHit) {
        const startPos = this.position.clone();
        startPos.y += this.size * 0.7; // Fire from turret height
        
        let targetPos = target.position.clone();
        
        // Lead target for moving projectiles
        if (this.projectileSpeed !== Infinity && target.velocity) {
            const timeToTarget = startPos.distanceTo(targetPos) / this.projectileSpeed;
            const leadPos = target.velocity.clone().multiplyScalar(timeToTarget);
            targetPos.add(leadPos);
        }
        
        // Add inaccuracy if miss
        if (!willHit) {
            const inaccuracy = this.range * 0.2; // 20% of range
            targetPos.x += (Math.random() - 0.5) * inaccuracy;
            targetPos.z += (Math.random() - 0.5) * inaccuracy;
        }
        
        const projectile = {
            id: Date.now() + Math.random(),
            type: this.projectileType,
            position: startPos.clone(),
            targetPosition: targetPos,
            target: willHit ? target : null,
            speed: this.projectileSpeed,
            damage: this.damage,
            tower: this,
            mesh: null,
            trail: [],
            lifetime: 0,
            maxLifetime: 5000, // 5 seconds
            willHit: willHit
        };
        
        // Create visual representation
        this.createProjectileMesh(projectile);
        
        return projectile;
    }
    
    createProjectileMesh(projectile) {
        let geometry, material;
        
        switch (projectile.type) {
            case 'bullet':
                geometry = new THREE.SphereGeometry(0.1, 6, 6);
                material = new THREE.MeshBasicMaterial({ color: 0xffff00 });
                break;
                
            case 'missile':
                geometry = new THREE.ConeGeometry(0.1, 0.4, 6);
                material = new THREE.MeshBasicMaterial({ color: 0xff4444 });
                break;
                
            case 'ice':
                geometry = new THREE.OctahedronGeometry(0.15, 0);
                material = new THREE.MeshBasicMaterial({ color: 0x88ddff });
                break;
                
            case 'poison':
                geometry = new THREE.SphereGeometry(0.12, 8, 8);
                material = new THREE.MeshBasicMaterial({ 
                    color: 0x44ff44,
                    transparent: true,
                    opacity: 0.8
                });
                break;
                
            case 'laser':
            case 'lightning':
                // These are instant hit, no mesh needed
                return;
                
            default:
                geometry = new THREE.SphereGeometry(0.08, 6, 6);
                material = new THREE.MeshBasicMaterial({ color: 0xffffff });
        }
        
        projectile.mesh = new THREE.Mesh(geometry, material);
        projectile.mesh.position.copy(projectile.position);
        
        // Add to scene using injected dependency
        if (this.scene) {
            this.scene.add(projectile.mesh);
        }
    }
    
    updateProjectiles(deltaTime, enemies) {
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const projectile = this.projectiles[i];
            
            // Update lifetime
            projectile.lifetime += deltaTime * 1000;
            
            // Remove expired projectiles
            if (projectile.lifetime > projectile.maxLifetime) {
                this.removeProjectile(i);
                continue;
            }
            
            // Update projectile based on type
            if (projectile.type === 'laser' || projectile.type === 'lightning') {
                this.updateInstantProjectile(projectile, enemies);
                this.removeProjectile(i);
            } else {
                this.updateMovingProjectile(projectile, deltaTime, enemies);
                
                // Check for impact
                if (this.checkProjectileImpact(projectile, enemies)) {
                    this.removeProjectile(i);
                }
            }
        }
    }
    
    updateInstantProjectile(projectile, enemies) {
        // Instant hit projectiles
        if (projectile.target && !projectile.target.isDead) {
            this.hitTarget(projectile.target, projectile.damage);
            
            // Special effects for instant projectiles
            this.createInstantProjectileEffect(projectile);
        }
    }
    
    updateMovingProjectile(projectile, deltaTime, enemies) {
        if (projectile.speed === Infinity) return;
        
        // Calculate movement
        const direction = projectile.targetPosition.clone().sub(projectile.position);
        const distance = direction.length();
        
        if (distance < 0.2) {
            // Reached target
            if (projectile.willHit && projectile.target && !projectile.target.isDead) {
                this.hitTarget(projectile.target, projectile.damage);
            }
            return true; // Mark for removal
        }
        
        // Move projectile
        direction.normalize();
        const movement = direction.multiplyScalar(projectile.speed * deltaTime);
        projectile.position.add(movement);
        
        // Update mesh position
        if (projectile.mesh) {
            projectile.mesh.position.copy(projectile.position);
            
            // Rotate to face movement direction
            projectile.mesh.lookAt(projectile.targetPosition);
        }
        
        return false;
    }
    
    checkProjectileImpact(projectile, enemies) {
        const impactRadius = 0.3;
        
        // Check collision with target
        if (projectile.target && !projectile.target.isDead) {
            const distance = projectile.position.distanceTo(projectile.target.position);
            if (distance <= impactRadius) {
                this.hitTarget(projectile.target, projectile.damage);
                this.createImpactEffect(projectile);
                return true;
            }
        }
        
        // Check collision with ground
        if (projectile.position.y <= 0) {
            this.createImpactEffect(projectile);
            return true;
        }
        
        return false;
    }
    
    hitTarget(target, damage) {
        const actualDamage = target.takeDamage(damage, this.getDamageType());
        
        // Update statistics
        this.stats.damageDealt += actualDamage;
        if (target.isDead) {
            this.stats.enemiesKilled++;
        }
        
        // Apply special effects
        this.applySpecialEffects(target);
    }
    
    getDamageType() {
        switch (this.projectileType) {
            case 'laser': return 'energy';
            case 'lightning': return 'lightning';
            case 'ice': return 'cold';
            case 'poison': return 'poison';
            case 'missile': return 'explosive';
            default: return 'physical';
        }
    }
    
    applySpecialEffects(target) {
        // Apply status effects based on tower abilities
        if (this.abilities.includes('slow_effect')) {
            target.addStatusEffect({
                type: 'slow',
                intensity: this.template.slowIntensity || 0.5,
                duration: this.template.slowDuration || 3000
            });
        }
        
        if (this.abilities.includes('poison_effect')) {
            target.addStatusEffect({
                type: 'poison',
                intensity: this.template.poisonDamage || 5,
                duration: this.template.poisonDuration || 5000
            });
        }
        
        if (this.abilities.includes('stun')) {
            target.addStatusEffect({
                type: 'stun',
                intensity: 1,
                duration: this.template.stunDuration || 1000
            });
        }
        
        // Chain lightning
        if (this.abilities.includes('chain_lightning')) {
            this.triggerChainLightning(target);
        }
        
        // Splash damage
        if (this.abilities.includes('splash_damage')) {
            this.triggerSplashDamage(target);
        }
    }
    
    triggerChainLightning(initialTarget) {
        const chainTargets = this.template.chainTargets || 3;
        const chainRange = this.range * 0.6;
        const chainDamage = this.damage * 0.7; // Reduced damage for chained targets
        
        let currentTarget = initialTarget;
        const hitTargets = new Set([initialTarget.id]);
        
        // Use injected getEnemies function instead of window.game
        const enemies = this.getEnemies ? this.getEnemies() : [];
        
        for (let i = 1; i < chainTargets; i++) {
            // Find nearest enemy to current target
            const nearbyEnemies = enemies.filter(enemy => {
                if (enemy.isDead || hitTargets.has(enemy.id)) return false;
                
                const distance = currentTarget.position.distanceTo(enemy.position);
                return distance <= chainRange;
            });
            
            if (nearbyEnemies.length === 0) break;
            
            // Find closest enemy
            const nextTarget = nearbyEnemies.reduce((closest, enemy) => {
                const distToCurrent = currentTarget.position.distanceTo(enemy.position);
                const distToClosest = currentTarget.position.distanceTo(closest.position);
                return distToCurrent < distToClosest ? enemy : closest;
            });
            
            // Hit the next target
            nextTarget.takeDamage(chainDamage, 'lightning');
            hitTargets.add(nextTarget.id);
            
            // Create visual effect
            this.createLightningEffect(currentTarget.position, nextTarget.position);
            
            currentTarget = nextTarget;
        }
    }
    
    triggerSplashDamage(target) {
        const splashRadius = this.template.splashRadius || 3;
        const splashDamage = this.damage * 0.5; // Reduced splash damage
        
        // Use injected getEnemies function instead of window.game
        const enemies = this.getEnemies ? this.getEnemies() : [];
        
        const nearbyEnemies = enemies.filter(enemy => {
            if (enemy.isDead || enemy.id === target.id) return false;
            
            const distance = target.position.distanceTo(enemy.position);
            return distance <= splashRadius;
        });
        
        nearbyEnemies.forEach(enemy => {
            const distance = target.position.distanceTo(enemy.position);
            const damageMultiplier = 1 - (distance / splashRadius);
            const finalDamage = splashDamage * damageMultiplier;
            
            enemy.takeDamage(finalDamage, this.getDamageType());
        });
        
        // Create explosion effect
        this.createExplosionEffect(target.position, splashRadius);
    }
    
    // Visual effect methods
    triggerMuzzleFlash() {
        if (!this.barrel) return;
        
        // Create muzzle flash
        const flashGeometry = new THREE.SphereGeometry(0.2, 8, 8);
        const flashMaterial = new THREE.MeshBasicMaterial({
            color: 0xffff88,
            transparent: true,
            opacity: 0.8
        });
        
        this.muzzleFlash = new THREE.Mesh(flashGeometry, flashMaterial);
        this.muzzleFlash.position.set(this.size * 0.6, 0, 0);
        this.turret.add(this.muzzleFlash);
        
        // Remove after short duration
        setTimeout(() => {
            if (this.muzzleFlash && this.turret) {
                this.turret.remove(this.muzzleFlash);
                this.muzzleFlash = null;
            }
        }, 100);
    }
    
    triggerFireEffect() {
        // Recoil animation
        if (this.turret) {
            const originalPosition = this.turret.position.clone();
            this.turret.position.x -= 0.1;
            
            setTimeout(() => {
                if (this.turret) {
                    this.turret.position.copy(originalPosition);
                }
            }, 50);
        }
    }
    
    createInstantProjectileEffect(projectile) {
        if (projectile.type === 'laser') {
            this.createLaserEffect(this.position, projectile.targetPosition);
        } else if (projectile.type === 'lightning') {
            this.createLightningEffect(this.position, projectile.targetPosition);
        }
    }
    
    createLaserEffect(start, end) {
        const direction = end.clone().sub(start);
        const distance = direction.length();
        
        const geometry = new THREE.CylinderGeometry(0.05, 0.05, distance, 8);
        const material = new THREE.MeshBasicMaterial({
            color: 0x00aaff,
            transparent: true,
            opacity: 0.8
        });
        
        const laser = new THREE.Mesh(geometry, material);
        laser.position.copy(start.clone().add(direction.clone().multiplyScalar(0.5)));
        laser.lookAt(end);
        laser.rotateX(Math.PI / 2);
        
        if (this.scene) {
            this.scene.add(laser);
            
            // Remove after short duration
            setTimeout(() => {
                this.scene.remove(laser);
            }, 200);
        }
    }
    
    createLightningEffect(start, end) {
        // Create jagged lightning bolt
        const points = [];
        const segments = 8;
        
        for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const point = start.clone().lerp(end, t);
            
            // Add randomness except for start and end points
            if (i > 0 && i < segments) {
                point.x += (Math.random() - 0.5) * 0.5;
                point.y += (Math.random() - 0.5) * 0.5;
                point.z += (Math.random() - 0.5) * 0.5;
            }
            
            points.push(point);
        }
        
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const material = new THREE.LineBasicMaterial({
            color: 0xffff00,
            linewidth: 3
        });
        
        const lightning = new THREE.Line(geometry, material);
        
        if (this.scene) {
            this.scene.add(lightning);
            
            // Remove after short duration
            setTimeout(() => {
                this.scene.remove(lightning);
            }, 150);
        }
    }
    
    createImpactEffect(projectile) {
        // Create impact particles
        const particle