// Resource Manager System
export class ResourceManager {
    constructor(notificationManager = null) {
        // Dependency injection - inject notification manager instead of accessing globally
        this.notificationManager = notificationManager;
        
        // Initialize resources
        this.resources = {
            gold: 100,        // Starting gold
            energy: 50,       // Starting energy
            score: 0,         // Player score
            lives: 3          // Player lives
        };
        
        // Resource generation
        this.goldPerSecond = 2;
        this.energyPerSecond = 1;
        this.lastIncomeTime = Date.now();
        
        // Statistics
        this.stats = {
            totalGoldEarned: 100,
            totalEnergyEarned: 50,
            totalGoldSpent: 0,
            totalEnergySpent: 0,
            enemiesDefeated: 0,
            towersBuilt: 0,
            wavesSurvived: 0
        };
        
        // Resource limits
        this.limits = {
            maxGold: 9999,
            maxEnergy: 999,
            maxScore: 999999
        };
        
        // Event callbacks
        this.onResourceChange = [];
        this.onInsufficientResources = [];
        
        // Passive income interval reference for cleanup
        this.passiveIncomeInterval = null;
        
        // Start passive income
        this.startPassiveIncome();
        
        console.log('ResourceManager initialized');
    }
    
    // Passive income system
    startPassiveIncome() {
        // Clear any existing interval to prevent duplicates
        if (this.passiveIncomeInterval) {
            clearInterval(this.passiveIncomeInterval);
        }
        
        this.passiveIncomeInterval = setInterval(() => {
            this.addGold(this.goldPerSecond);
            this.addEnergy(this.energyPerSecond);
        }, 1000); // Every second
    }
    
    // Method to stop passive income (useful for cleanup)
    stopPassiveIncome() {
        if (this.passiveIncomeInterval) {
            clearInterval(this.passiveIncomeInterval);
            this.passiveIncomeInterval = null;
        }
    }
    
    // Gold management
    addGold(amount) {
        const oldGold = this.resources.gold;
        this.resources.gold = Math.min(this.resources.gold + amount, this.limits.maxGold);
        this.stats.totalGoldEarned += amount;
        
        if (this.resources.gold !== oldGold) {
            this.notifyResourceChange('gold', this.resources.gold, oldGold);
        }
        
        return this.resources.gold;
    }
    
    spendGold(amount) {
        if (this.resources.gold >= amount) {
            const oldGold = this.resources.gold;
            this.resources.gold -= amount;
            this.stats.totalGoldSpent += amount;
            
            this.notifyResourceChange('gold', this.resources.gold, oldGold);
            return true;
        } else {
            this.notifyInsufficientResources('gold', amount, this.resources.gold);
            return false;
        }
    }
    
    getGold() {
        return this.resources.gold;
    }
    
    // Energy management
    addEnergy(amount) {
        const oldEnergy = this.resources.energy;
        this.resources.energy = Math.min(this.resources.energy + amount, this.limits.maxEnergy);
        this.stats.totalEnergyEarned += amount;
        
        if (this.resources.energy !== oldEnergy) {
            this.notifyResourceChange('energy', this.resources.energy, oldEnergy);
        }
        
        return this.resources.energy;
    }
    
    spendEnergy(amount) {
        if (this.resources.energy >= amount) {
            const oldEnergy = this.resources.energy;
            this.resources.energy -= amount;
            this.stats.totalEnergySpent += amount;
            
            this.notifyResourceChange('energy', this.resources.energy, oldEnergy);
            return true;
        } else {
            this.notifyInsufficientResources('energy', amount, this.resources.energy);
            return false;
        }
    }
    
    getEnergy() {
        return this.resources.energy;
    }
    
    // Score management
    addScore(amount) {
        const oldScore = this.resources.score;
        this.resources.score = Math.min(this.resources.score + amount, this.limits.maxScore);
        
        if (this.resources.score !== oldScore) {
            this.notifyResourceChange('score', this.resources.score, oldScore);
        }
        
        return this.resources.score;
    }
    
    getScore() {
        return this.resources.score;
    }
    
    // Lives management
    getLives() {
        return this.resources.lives;
    }
    
    loseLive() {
        if (this.resources.lives > 0) {
            const oldLives = this.resources.lives;
            this.resources.lives--;
            this.notifyResourceChange('lives', this.resources.lives, oldLives);
            return true;
        }
        return false;
    }
    
    // Resource checking
    canAfford(goldCost = 0, energyCost = 0) {
        return this.resources.gold >= goldCost && this.resources.energy >= energyCost;
    }
    
    // Bulk operations
    spendResources(goldCost = 0, energyCost = 0) {
        if (this.canAfford(goldCost, energyCost)) {
            this.spendGold(goldCost);
            this.spendEnergy(energyCost);
            return true;
        }
        return false;
    }
    
    // Statistics
    recordEnemyDefeated() {
        this.stats.enemiesDefeated++;
    }
    
    recordTowerBuilt() {
        this.stats.towersBuilt++;
    }
    
    recordWaveSurvived() {
        this.stats.wavesSurvived++;
    }
    
    getEnemiesDefeated() {
        return this.stats.enemiesDefeated;
    }
    
    getTowersBuilt() {
        return this.stats.towersBuilt;
    }
    
    getWavesSurvived() {
        return this.stats.wavesSurvived;
    }
    
    // Income management
    setGoldPerSecond(amount) {
        this.goldPerSecond = Math.max(0, amount);
    }
    
    setEnergyPerSecond(amount) {
        this.energyPerSecond = Math.max(0, amount);
    }
    
    getGoldPerSecond() {
        return this.goldPerSecond;
    }
    
    getEnergyPerSecond() {
        return this.energyPerSecond;
    }
    
    // Upgrade income rates
    upgradeGoldIncome(cost) {
        if (this.spendGold(cost)) {
            this.goldPerSecond += 1;
            return true;
        }
        return false;
    }
    
    upgradeEnergyIncome(cost) {
        if (this.spendGold(cost)) {
            this.energyPerSecond += 1;
            return true;
        }
        return false;
    }
    
    // Event system
    onResourceChanged(callback) {
        this.onResourceChange.push(callback);
    }
    
    onInsufficientResource(callback) {
        this.onInsufficientResources.push(callback);
    }
    
    notifyResourceChange(resourceType, newValue, oldValue) {
        this.onResourceChange.forEach(callback => {
            try {
                callback(resourceType, newValue, oldValue);
            } catch (error) {
                console.error('Error in resource change callback:', error);
            }
        });
    }
    
    notifyInsufficientResources(resourceType, required, available) {
        // Use injected notification manager if available
        if (this.notificationManager) {
            this.notificationManager.showInsufficientResources(resourceType, required, available);
        }
        
        // Also call registered callbacks
        this.onInsufficientResources.forEach(callback => {
            try {
                callback(resourceType, required, available);
            } catch (error) {
                console.error('Error in insufficient resources callback:', error);
            }
        });
    }
    
    // Save/Load system
    saveState() {
        return {
            resources: { ...this.resources },
            stats: { ...this.stats },
            goldPerSecond: this.goldPerSecond,
            energyPerSecond: this.energyPerSecond
        };
    }
    
    loadState(state) {
        if (state.resources) {
            this.resources = { ...state.resources };
        }
        if (state.stats) {
            this.stats = { ...state.stats };
        }
        if (state.goldPerSecond !== undefined) {
            this.goldPerSecond = state.goldPerSecond;
        }
        if (state.energyPerSecond !== undefined) {
            this.energyPerSecond = state.energyPerSecond;
        }
        
        // Restart passive income with new rates
        this.startPassiveIncome();
        
        // Notify all resource changes
        Object.keys(this.resources).forEach(resourceType => {
            this.notifyResourceChange(resourceType, this.resources[resourceType], 0);
        });
    }
    
    // Reset resources
    reset() {
        this.resources = {
            gold: 100,
            energy: 50,
            score: 0,
            lives: 3
        };
        
        this.stats = {
            totalGoldEarned: 100,
            totalEnergyEarned: 50,
            totalGoldSpent: 0,
            totalEnergySpent: 0,
            enemiesDefeated: 0,
            towersBuilt: 0,
            wavesSurvived: 0
        };
        
        this.goldPerSecond = 2;
        this.energyPerSecond = 1;
        
        // Restart passive income
        this.startPassiveIncome();
        
        // Notify reset
        Object.keys(this.resources).forEach(resourceType => {
            this.notifyResourceChange(resourceType, this.resources[resourceType], 0);
        });
    }
    
    // Cleanup method (important for proper resource management)
    destroy() {
        this.stopPassiveIncome();
        this.onResourceChange = [];
        this.onInsufficientResources = [];
        this.notificationManager = null;
    }
    
    // Debug methods
    getAllResources() {
        return { ...this.resources };
    }
    
    getAllStats() {
        return { ...this.stats };
    }
    
    getDebugInfo() {
        return {
            resources: this.resources,
            stats: this.stats,
            income: {
                goldPerSecond: this.goldPerSecond,
                energyPerSecond: this.energyPerSecond
            },
            limits: this.limits,
            hasNotificationManager: !!this.notificationManager
        };
    }
    
    // Cheat methods (for testing)
    cheatAddGold(amount) {
        this.addGold(amount);
    }
    
    cheatAddEnergy(amount) {
        this.addEnergy(amount);
    }
    
    cheatMaxResources() {
        this.resources.gold = this.limits.maxGold;
        this.resources.energy = this.limits.maxEnergy;
        
        this.notifyResourceChange('gold', this.resources.gold, 0);
        this.notifyResourceChange('energy', this.resources.energy, 0);
    }
}

// No longer attaching to window - use ES6 modules instead