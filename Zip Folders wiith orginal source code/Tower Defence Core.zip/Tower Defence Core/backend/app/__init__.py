from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO
import os

db = SQLAlchemy()
socketio = SocketIO()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key'
    
    # Database configuration
    db_user = os.environ.get('DB_USER', 'your_mysql_username')
    db_password = os.environ.get('DB_PASSWORD', 'your_mysql_password')
    db_host = os.environ.get('DB_HOST', 'localhost')
    db_name = os.environ.get('DB_NAME', 'tower_defense_db')
    
    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+mysqlconnector://{db_user}:{db_password}@{db_host}/{db_name}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*")

    with app.app_context():
        from . import models
        from . import events
        from .routes import api_bp  # Import the blueprint
        app.register_blueprint(api_bp)  # Register the blueprint
        db.create_all()

    return app
