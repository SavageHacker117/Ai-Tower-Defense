// Wave Manager System
class WaveManager {
    constructor(game) {
        this.game = game;
        
        // Wave state
        this.currentWave = 0;
        this.totalWaves = 0;
        this.isWaveActive = false;
        this.waveData = null;
        this.levelData = null;
        
        // Spawning
        this.spawnQueue = [];
        this.spawnedEnemies = [];
        this.lastSpawnTime = 0;
        this.waveStartTime = 0;
        this.waveEndTime = 0;
        
        // Timing
        this.preWaveDelay = 5000; // 5 seconds between waves
        this.waveTimer = null;
        this.spawnTimer = null;
        
        // Auto-progression
        this.autoStartNextWave = false;
        this.autoStartDelay = 3000; // 3 seconds
        
        // Event callbacks
        this.onWaveStartCallbacks = [];
        this.onWaveCompleteCallbacks = [];
        this.onWaveFailedCallbacks = [];
        this.onAllWavesCompleteCallbacks = [];
        
        // Statistics
        this.waveStats = {
            enemiesSpawned: 0,
            enemiesKilled: 0,
            enemiesReachedEnd: 0,
            waveStartTime: 0,
            waveEndTime: 0,
            waveDuration: 0
        };
        
        console.log('WaveManager initialized');
    }
    
    // Initialize with level data
    async initialize(levelNumber) {
        try {
            // Load level data
            this.levelData = await this.game.levelData.loadLevel(levelNumber);
            if (!this.levelData) {
                throw new Error(`Failed to load level ${levelNumber}`);
            }
            
            this.totalWaves = this.levelData.totalWaves;
            this.currentWave = 0;
            this.isWaveActive = false;
            
            // Reset state
            this.spawnQueue = [];
            this.spawnedEnemies = [];
            this.resetWaveStats();
            
            console.log(`WaveManager initialized for level ${levelNumber} with ${this.totalWaves} waves`);
            return true;
            
        } catch (error) {
            console.error('Failed to initialize WaveManager:', error);
            return false;
        }
    }
    
    // Start the next wave
    startNextWave() {
        if (this.isWaveActive) {
            console.warn('Cannot start wave: wave already active');
            return false;
        }
        
        if (this.currentWave >= this.totalWaves) {
            console.warn('Cannot start wave: all waves completed');
            return false;
        }
        
        this.currentWave++;
        this.waveData = this.levelData.waves[this.currentWave - 1];
        
        if (!this.waveData) {
            console.error(`Wave data not found for wave ${this.currentWave}`);
            return false;
        }
        
        // Setup wave
        this.setupWave();
        
        // Start wave after delay
        setTimeout(() => {
            this.beginWave();
        }, this.waveData.preWaveDelay || this.preWaveDelay);
        
        return true;
    }
    
    setupWave() {
        // Reset wave state
        this.isWaveActive = true;
        this.spawnQueue = [];
        this.spawnedEnemies = [];
        this.lastSpawnTime = 0;
        this.resetWaveStats();
        
        // Create spawn queue from wave data
        this.createSpawnQueue();
        
        // Notify wave start
        this.triggerWaveStartCallbacks();
        
        console.log(`Wave ${this.currentWave} setup complete: ${this.spawnQueue.length} spawn events`);
    }
    
    createSpawnQueue() {
        const waveStartTime = Date.now();
        
        this.waveData.enemies.forEach(enemyGroup => {
            const spawnDelay = enemyGroup.delay || 0;
            const spawnInterval = enemyGroup.interval || 1000;
            
            for (let i = 0; i < enemyGroup.count; i++) {
                const spawnTime = waveStartTime + spawnDelay + (i * spawnInterval);
                
                this.spawnQueue.push({
                    enemyType: enemyGroup.type,
                    spawnTime: spawnTime,
                    spawned: false
                });
            }
        });
        
        // Sort by spawn time
        this.spawnQueue.sort((a, b) => a.spawnTime - b.spawnTime);
    }
    
    beginWave() {
        this.waveStartTime = Date.now();
        this.waveStats.waveStartTime = this.waveStartTime;
        
        // Show wave start notification
        if (this.game.notificationManager) {
            this.game.notificationManager.showWaveStart(this.currentWave);
        }
        
        // Start spawn timer
        this.startSpawnTimer();
        
        console.log(`Wave ${this.currentWave} started`);
    }
    
    startSpawnTimer() {
        this.spawnTimer = setInterval(() => {
            this.updateSpawning();
        }, 100); // Check every 100ms
    }
    
    updateSpawning() {
        const now = Date.now();
        
        // Process spawn queue
        this.spawnQueue.forEach(spawnEvent => {
            if (!spawnEvent.spawned && now >= spawnEvent.spawnTime) {
                this.spawnEnemy(spawnEvent.enemyType);
                spawnEvent.spawned = true;
                this.waveStats.enemiesSpawned++;
            }
        });
        
        // Check if all enemies spawned
        const allSpawned = this.spawnQueue.every(event => event.spawned);
        
        if (allSpawned) {
            this.stopSpawnTimer();
            this.startWaveCompletionCheck();
        }
    }
    
    spawnEnemy(enemyType) {
        try {
            // Get spawn position
            const spawnPos = this.game.mapData.getSpawnPoint();
            
            // Get enemy path
            const path = this.game.getEnemyPath();
            
            // Create enemy
            const enemy = EnemyFactory.createEnemy(
                enemyType,
                this.levelData.levelNumber,
                spawnPos,
                path
            );
            
            if (enemy) {
                this.spawnedEnemies.push(enemy);
                
                // Add to game
                this.game.addEnemy(enemy);
                
                console.log(`Spawned ${enemyType} enemy`);
            } else {
                console.error(`Failed to spawn ${enemyType} enemy`);
            }
            
        } catch (error) {
            console.error('Error spawning enemy:', error);
        }
    }
    
    startWaveCompletionCheck() {
        this.waveTimer = setInterval(() => {
            this.checkWaveCompletion();
        }, 500); // Check every 500ms
    }
    
    checkWaveCompletion() {
        const activeEnemies = this.game.getEnemies().filter(enemy => !enemy.isDead);
        
        if (activeEnemies.length === 0) {
            this.completeWave();
        }
    }
    
    completeWave() {
        this.isWaveActive = false;
        this.waveEndTime = Date.now();
        this.waveStats.waveEndTime = this.waveEndTime;
        this.waveStats.waveDuration = this.waveEndTime - this.waveStartTime;
        
        // Stop timers
        this.stopSpawnTimer();
        this.stopWaveTimer();
        
        // Calculate wave results
        const waveResults = this.calculateWaveResults();
        
        // Award rewards
        this.awardWaveRewards(waveResults);
        
        // Show completion notification
        if (this.game.notificationManager) {
            this.game.notificationManager.showWaveComplete(this.currentWave);
        }
        
        // Trigger callbacks
        this.triggerWaveCompleteCallbacks(waveResults);
        
        // Check if all waves completed
        if (this.currentWave >= this.totalWaves) {
            this.completeAllWaves();
        } else if (this.autoStartNextWave) {
            // Auto-start next wave
            setTimeout(() => {
                this.startNextWave();
            }, this.autoStartDelay);
        }
        
        console.log(`Wave ${this.currentWave} completed in ${this.waveStats.waveDuration}ms`);
    }
    
    calculateWaveResults() {
        const totalEnemies = this.waveStats.enemiesSpawned;
        const enemiesKilled = this.waveStats.enemiesKilled;
        const enemiesReachedEnd = this.waveStats.enemiesReachedEnd;
        
        const killRate = totalEnemies > 0 ? enemiesKilled / totalEnemies : 0;
        const survivalRate = totalEnemies > 0 ? (totalEnemies - enemiesReachedEnd) / totalEnemies : 1;
        
        return {
            waveNumber: this.currentWave,
            totalEnemies: totalEnemies,
            enemiesKilled: enemiesKilled,
            enemiesReachedEnd: enemiesReachedEnd,
            killRate: killRate,
            survivalRate: survivalRate,
            waveDuration: this.waveStats.waveDuration,
            perfect: enemiesReachedEnd === 0,
            rating: this.calculateWaveRating(killRate, survivalRate)
        };
    }
    
    calculateWaveRating(killRate, survivalRate) {
        const score = (killRate * 0.6 + survivalRate * 0.4) * 100;
        
        if (score >= 95) return 'S';
        if (score >= 85) return 'A';
        if (score >= 75) return 'B';
        if (score >= 65) return 'C';
        return 'D';
    }
    
    awardWaveRewards(results) {
        if (!this.waveData.rewards) return;
        
        const baseRewards = this.waveData.rewards;
        const multiplier = results.survivalRate;
        
        const rewards = {
            gold: Math.floor(baseRewards.gold * multiplier),
            energy: Math.floor(baseRewards.energy * multiplier),
            score: Math.floor(baseRewards.score * multiplier)
        };
        
        // Award to resource manager
        if (this.game.resourceManager) {
            this.game.resourceManager.addGold(rewards.gold);
            this.game.resourceManager.addEnergy(rewards.energy);
            this.game.resourceManager.addScore(rewards.score);
        }
        
        // Show reward notifications
        if (this.game.notificationManager) {
            if (rewards.gold > 0) {
                this.game.notificationManager.showResourceGained('gold', rewards.gold);
            }
            if (rewards.energy > 0) {
                this.game.notificationManager.showResourceGained('energy', rewards.energy);
            }
            if (rewards.score > 0) {
                this.game.notificationManager.showResourceGained('score', rewards.score);
            }
        }
        
        console.log('Wave rewards awarded:', rewards);
    }
    
    completeAllWaves() {
        // Calculate level results
        const levelResults = this.calculateLevelResults();
        
        // Award level completion rewards
        this.awardLevelRewards(levelResults);
        
        // Show completion notification
        if (this.game.notificationManager) {
            this.game.notificationManager.showLevelComplete();
        }
        
        // Trigger callbacks
        this.triggerAllWavesCompleteCallbacks(levelResults);
        
        console.log(`All waves completed for level ${this.levelData.levelNumber}`);
    }
    
    calculateLevelResults() {
        // Aggregate statistics from all waves
        return {
            levelNumber: this.levelData.levelNumber,
            totalWaves: this.totalWaves,
            completed: true,
            // Add more level statistics as needed
        };
    }
    
    awardLevelRewards(results) {
        if (!this.levelData.rewards) return;
        
        const rewards = this.levelData.rewards;
        
        // Award to resource manager
        if (this.game.resourceManager) {
            this.game.resourceManager.addGold(rewards.gold);
            this.game.resourceManager.addEnergy(rewards.energy);
            this.game.resourceManager.addScore(rewards.score);
        }
        
        console.log('Level completion rewards awarded:', rewards);
    }
    
    // Handle enemy events
    onEnemyKilled(enemy) {
        this.waveStats.enemiesKilled++;
        
        // Remove from spawned enemies list
        const index = this.spawnedEnemies.findIndex(e => e.id === enemy.id);
        if (index >= 0) {
            this.spawnedEnemies.splice(index, 1);
        }
    }
    
    onEnemyReachedEnd(enemy) {
        this.waveStats.enemiesReachedEnd++;
        
        // Remove from spawned enemies list
        const index = this.spawnedEnemies.findIndex(e => e.id === enemy.id);
        if (index >= 0) {
            this.spawnedEnemies.splice(index, 1);
        }
        
        // Damage player
        if (this.game.playerHealthSystem) {
            this.game.playerHealthSystem.takeDamage(enemy.damage);
        }
    }
    
    // Wave control
    skipWave() {
        if (!this.isWaveActive) return false;
        
        // Kill all remaining enemies
        this.spawnedEnemies.forEach(enemy => {
            if (!enemy.isDead) {
                enemy.die();
            }
        });
        
        // Force wave completion
        this.completeWave();
        
        return true;
    }
    
    pauseWave() {
        if (this.spawnTimer) {
            clearInterval(this.spawnTimer);
            this.spawnTimer = null;
        }
        
        if (this.waveTimer) {
            clearInterval(this.waveTimer);
            this.waveTimer = null;
        }
    }
    
    resumeWave() {
        if (this.isWaveActive) {
            // Check if still spawning
            const allSpawned = this.spawnQueue.every(event => event.spawned);
            
            if (!allSpawned) {
                this.startSpawnTimer();
            } else {
                this.startWaveCompletionCheck();
            }
        }
    }
    
    // Timer management
    stopSpawnTimer() {
        if (this.spawnTimer) {
            clearInterval(this.spawnTimer);
            this.spawnTimer = null;
        }
    }
    
    stopWaveTimer() {
        if (this.waveTimer) {
            clearInterval(this.waveTimer);
            this.waveTimer = null;
        }
    }
    
    // Event system
    onWaveStart(callback) {
        this.onWaveStartCallbacks.push(callback);
    }
    
    onWaveComplete(callback) {
        this.onWaveCompleteCallbacks.push(callback);
    }
    
    onWaveFailed(callback) {
        this.onWaveFailedCallbacks.push(callback);
    }
    
    onAllWavesComplete(callback) {
        this.onAllWavesCompleteCallbacks.push(callback);
    }
    
    triggerWaveStartCallbacks() {
        this.onWaveStartCallbacks.forEach(callback => {
            try {
                callback(this.currentWave);
            } catch (error) {
                console.error('Error in wave start callback:', error);
            }
        });
    }
    
    triggerWaveCompleteCallbacks(results) {
        this.onWaveCompleteCallbacks.forEach(callback => {
            try {
                callback(this.currentWave, results);
            } catch (error) {
                console.error('Error in wave complete callback:', error);
            }
        });
    }
    
    triggerWaveFailedCallbacks() {
        this.onWaveFailedCallbacks.forEach(callback => {
            try {
                callback(this.currentWave);
            } catch (error) {
                console.error('Error in wave failed callback:', error);
            }
        });
    }
    
    triggerAllWavesCompleteCallbacks(results) {
        this.onAllWavesCompleteCallbacks.forEach(callback => {
            try {
                callback(results);
            } catch (error) {
                console.error('Error in all waves complete callback:', error);
            }
        });
    }
    
    // Getters
    getCurrentWave() {
        return this.currentWave;
    }
    
    getTotalWaves() {
        return this.totalWaves;
    }
    
    isActive() {
        return this.isWaveActive;
    }
    
    canStartNextWave() {
        return !this.isWaveActive && this.currentWave < this.totalWaves;
    }
    
    getWaveProgress() {
        if (!this.isWaveActive || this.spawnQueue.length === 0) return 0;
        
        const spawnedCount = this.spawnQueue.filter(event => event.spawned).length;
        return spawnedCount / this.spawnQueue.length;
    }
    
    getTimeUntilNextSpawn() {
        if (!this.isWaveActive) return 0;
        
        const now = Date.now();
        const nextSpawn = this.spawnQueue.find(event => !event.spawned);
        
        if (!nextSpawn) return 0;
        
        return Math.max(0, nextSpawn.spawnTime - now);
    }
    
    getRemainingEnemies() {
        return this.spawnQueue.filter(event => !event.spawned).length;
    }
    
    getActiveEnemies() {
        return this.spawnedEnemies.filter(enemy => !enemy.isDead);
    }
    
    getWaveStats() {
        return { ...this.waveStats };
    }
    
    getWaveData() {
        return this.waveData;
    }
    
    // Settings
    setAutoStartNextWave(enabled) {
        this.autoStartNextWave = enabled;
    }
    
    setAutoStartDelay(delay) {
        this.autoStartDelay = Math.max(1000, delay);
    }
    
    setPreWaveDelay(delay) {
        this.preWaveDelay = Math.max(1000, delay);
    }
    
    // Utility methods
    resetWaveStats() {
        this.waveStats = {
            enemiesSpawned: 0,
            enemiesKilled: 0,
            enemiesReachedEnd: 0,
            waveStartTime: 0,
            waveEndTime: 0,
            waveDuration: 0
        };
    }
    
    getEstimatedWaveDuration() {
        if (!this.waveData) return 0;
        return this.waveData.totalDuration || 30000; // Default 30 seconds
    }
    
    getWaveDescription() {
        if (!this.waveData) return '';
        
        const enemyTypes = [...new Set(this.waveData.enemies.map(e => e.type))];
        const totalEnemies = this.waveData.enemies.reduce((sum, e) => sum + e.count, 0);
        
        return `${totalEnemies} enemies (${enemyTypes.join(', ')})`;
    }
    
    // Debug methods
    getDebugInfo() {
        return {
            currentWave: this.currentWave,
            totalWaves: this.totalWaves,
            isWaveActive: this.isWaveActive,
            spawnQueueLength: this.spawnQueue.length,
            spawnedEnemiesCount: this.spawnedEnemies.length,
            waveStats: this.waveStats,
            autoStartNextWave: this.autoStartNextWave
        };
    }
    
    // Cleanup
    dispose() {
        this.stopSpawnTimer();
        this.stopWaveTimer();
        
        this.spawnQueue = [];
        this.spawnedEnemies = [];
        
        this.onWaveStartCallbacks = [];
        this.onWaveCompleteCallbacks = [];
        this.onWaveFailedCallbacks = [];
        this.onAllWavesCompleteCallbacks = [];
    }
}

// Export for use in other modules
window.WaveManager = WaveManager;

