// Main Game Entry Point
class Game {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.canvas = null;
        
        // Game Systems
        this.gameLoop = null;
        this.resourceManager = null;
        this.playerHealthSystem = null;
        this.audioManager = null;
        this.inputManager = null;
        this.notificationManager = null;
        this.hudManager = null;
        this.enemyUIManager = null;
        this.waveManager = null;
        this.towerSystem = null;
        this.targetingSystem = null;
        this.projectileSystem = null;
        this.healthSystem = null;
        this.statusEffectSystem = null;
        this.bossAISystem = null;
        this.particleSystem = null;
        this.visualFeedbackSystem = null;
        this.towerStoreUI = null;
        this.pathfinding = null;
        
        // Game State
        this.gameState = 'loading'; // loading, playing, paused, gameOver
        this.currentLevel = 1;
        this.gameSpeed = 1;
        this.isPaused = false;
        
        // Game Objects
        this.enemies = [];
        this.towers = [];
        this.projectiles = [];
        this.particles = [];
        
        // Map and Level Data
        this.mapData = null;
        this.levelData = null;
        this.enemyPath = [];
        
        // Performance Tracking
        this.lastFrameTime = 0;
        this.deltaTime = 0;
        this.fps = 0;
        this.frameCount = 0;
        
        // Initialize the game
        this.init();
    }
    
    async init() {
        try {
            console.log('Initializing AI-Powered 3D Tower Defense Game...');
            
            // Initialize Three.js
            await this.initThreeJS();
            
            // Initialize game systems
            await this.initGameSystems();
            
            // Load game data
            await this.loadGameData();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Hide loading screen and start game
            this.hideLoadingScreen();
            
            // Start the game loop
            this.startGame();
            
            console.log('Game initialized successfully!');
            
        } catch (error) {
            console.error('Failed to initialize game:', error);
            this.showError('Failed to initialize game. Please refresh the page.');
        }
    }
    
    async initThreeJS() {
        // Get canvas element
        this.canvas = document.getElementById('gameCanvas');
        if (!this.canvas) {
            throw new Error('Game canvas not found');
        }
        
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x87CEEB); // Sky blue background
        
        // Create camera
        const aspect = window.innerWidth / window.innerHeight;
        this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
        this.camera.position.set(0, 20, 15);
        this.camera.lookAt(0, 0, 0);
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({ 
            canvas: this.canvas, 
            antialias: true 
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        
        // Add lights
        this.setupLighting();
        
        // Add basic ground plane
        this.createGround();
        
        console.log('Three.js initialized');
    }
    
    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
        this.scene.add(ambientLight);
        
        // Directional light (sun)
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(10, 20, 5);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 2048;
        directionalLight.shadow.mapSize.height = 2048;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -20;
        directionalLight.shadow.camera.right = 20;
        directionalLight.shadow.camera.top = 20;
        directionalLight.shadow.camera.bottom = -20;
        this.scene.add(directionalLight);
        
        // Point light for dynamic lighting
        const pointLight = new THREE.PointLight(0xff6600, 0.5, 30);
        pointLight.position.set(0, 10, 0);
        this.scene.add(pointLight);
    }
    
    createGround() {
        // Create ground geometry
        const groundGeometry = new THREE.PlaneGeometry(40, 30);
        const groundMaterial = new THREE.MeshLambertMaterial({ 
            color: 0x228B22,
            transparent: true,
            opacity: 0.8
        });
        
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        this.scene.add(ground);
        
        // Add grid helper
        const gridHelper = new THREE.GridHelper(40, 40, 0x444444, 0x444444);
        gridHelper.material.opacity = 0.3;
        gridHelper.material.transparent = true;
        this.scene.add(gridHelper);
    }
    
    async initGameSystems() {
        // Initialize core systems
        this.resourceManager = new ResourceManager();
        this.playerHealthSystem = new PlayerHealthSystem(3); // 3 lives
        this.audioManager = new AudioManager();
        this.inputManager = new InputManager(this);
        this.notificationManager = new NotificationManager();
        this.hudManager = new HUDManager(this);
        this.enemyUIManager = new EnemyUIManager();
        
        // Initialize game logic systems
        this.pathfinding = new Pathfinding();
        this.towerSystem = new TowerSystem(this);
        this.targetingSystem = new TargetingSystem(this);
        this.projectileSystem = new ProjectileSystem(this);
        this.statusEffectSystem = new StatusEffectSystem(this);
        this.healthSystem = new HealthSystem(this);
        this.bossAISystem = new BossAISystem(this);
        this.visualFeedbackSystem = new VisualFeedbackSystem(this);
        this.multiplayerManager = new MultiplayerManager(this);
        this.authManager = new AuthManager(this);
        
        // Initialize wave manager (depends on other systems)
        this.waveManager = new WaveManager(this);
        
        // Initialize UI systems that depend on game systems
        this.towerStoreUI = new TowerStoreUI(this);
        
        // Initialize game loop
        this.gameLoop = new GameLoop(this);
        
        console.log('Game systems initialized');
    }
    
    async loadGameData() {
        // Load map data
        this.mapData = new MapData();
        await this.mapData.loadLevel(this.currentLevel);
        
        // Load level data
        this.levelData = new LevelData();
        await this.levelData.loadLevel(this.currentLevel);
        
        // Initialize pathfinding with map data
        this.pathfinding.initializeGrid(this.mapData);
        
        // Generate enemy path
        this.enemyPath = this.pathfinding.generatePath(
            this.mapData.getSpawnPoint(),
            this.mapData.getEndPoint(),
            this.mapData.getObstacles()
        );
        
        // Create path visualization
        this.visualizePath();
        
        console.log('Game data loaded');
    }
    
    visualizePath() {
        if (this.enemyPath.length < 2) return;
        
        // Create path line
        const pathGeometry = new THREE.BufferGeometry();
        const pathPoints = this.enemyPath.map(point => new THREE.Vector3(point.x, 0.1, point.z));
        pathGeometry.setFromPoints(pathPoints);
        
        const pathMaterial = new THREE.LineBasicMaterial({ 
            color: 0xff6600,
            linewidth: 3
        });
        
        const pathLine = new THREE.Line(pathGeometry, pathMaterial);
        this.scene.add(pathLine);
        
        // Add path markers
        this.enemyPath.forEach((point, index) => {
            if (index % 3 === 0) { // Every 3rd point
                const markerGeometry = new THREE.SphereGeometry(0.2, 8, 8);
                const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xff6600 });
                const marker = new THREE.Mesh(markerGeometry, markerMaterial);
                marker.position.set(point.x, 0.2, point.z);
                this.scene.add(marker);
            }
        });
    }
    
    setupEventListeners() {
        // Window resize
        window.addEventListener('resize', () => this.onWindowResize());
        
        // Keyboard events
        document.addEventListener('keydown', (event) => this.inputManager.onKeyDown(event));
        document.addEventListener('keyup', (event) => this.inputManager.onKeyUp(event));
        
        // Mouse events
        this.canvas.addEventListener('click', (event) => this.inputManager.onClick(event));
        this.canvas.addEventListener('mousemove', (event) => this.inputManager.onMouseMove(event));
        
        // Game control buttons
        document.getElementById('pauseBtn').addEventListener('click', () => this.togglePause());
        document.getElementById('speedBtn').addEventListener('click', () => this.toggleSpeed());
        document.getElementById('nextWaveBtn').addEventListener('click', () => this.startNextWave());
        
        console.log('Event listeners setup');
    }
    
    onWindowResize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        
        this.renderer.setSize(width, height);
    }
    
    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
    }
    
    showError(message) {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.innerHTML = `
                <div style="color: #ff4444; text-align: center;">
                    <h2>Error</h2>
                    <p>${message}</p>
                    <button onclick="location.reload()" style="margin-top: 20px; padding: 10px 20px; background: #ff4444; color: white; border: none; border-radius: 5px; cursor: pointer;">
                        Reload Game
                    </button>
                </div>
            `;
        }
    }
    
    startGame() {
        this.gameState = 'playing';
        this.gameLoop.start();
        this.notificationManager.show('Game Started!', 2000);
        this.audioManager.playBackgroundMusic();
        
        // Start first wave after a delay
        setTimeout(() => {
            this.waveManager.startWave(1);
        }, 3000);
    }
    
    togglePause() {
        if (this.gameState === 'playing') {
            this.gameState = 'paused';
            this.isPaused = true;
            document.getElementById('pauseBtn').textContent = 'Resume';
            this.notificationManager.show('Game Paused', 1000);
        } else if (this.gameState === 'paused') {
            this.gameState = 'playing';
            this.isPaused = false;
            document.getElementById('pauseBtn').textContent = 'Pause';
            this.notificationManager.show('Game Resumed', 1000);
        }
    }
    
    toggleSpeed() {
        const speedBtn = document.getElementById('speedBtn');
        if (this.gameSpeed === 1) {
            this.gameSpeed = 2;
            speedBtn.textContent = 'Speed x2';
        } else if (this.gameSpeed === 2) {
            this.gameSpeed = 3;
            speedBtn.textContent = 'Speed x3';
        } else {
            this.gameSpeed = 1;
            speedBtn.textContent = 'Speed x1';
        }
        this.notificationManager.show(`Speed: ${this.gameSpeed}x`, 1000);
    }
    
    startNextWave() {
        if (this.waveManager.canStartNextWave()) {
            this.waveManager.startNextWave();
        }
    }
    
    update(deltaTime) {
        if (this.isPaused) return;
        
        // Apply game speed
        const adjustedDeltaTime = deltaTime * this.gameSpeed;
        
        // Update all game systems
        this.waveManager.update(adjustedDeltaTime);
        this.towerSystem.update(adjustedDeltaTime);
        this.targetingSystem.update(adjustedDeltaTime);
        this.projectileSystem.update(adjustedDeltaTime);
        this.healthSystem.update(adjustedDeltaTime);
        this.statusEffectSystem.update(adjustedDeltaTime);
        this.bossAISystem.update(adjustedDeltaTime);
        this.particleSystem.update(adjustedDeltaTime);
        this.visualFeedbackSystem.update(adjustedDeltaTime);
        
        // Update enemies
        this.updateEnemies(adjustedDeltaTime);
        
        // Update UI
        this.hudManager.update();
        this.enemyUIManager.update(this.enemies);
        
        // Check game over conditions
        this.checkGameOver();
    }
    
    updateEnemies(deltaTime) {
        for (let i = this.enemies.length - 1; i >= 0; i--) {
            const enemy = this.enemies[i];
            
            if (enemy.isDead) {
                // Remove dead enemy
                this.scene.remove(enemy.mesh);
                this.enemies.splice(i, 1);
                
                // Award resources
                this.resourceManager.addGold(enemy.bounty);
                this.resourceManager.addScore(enemy.scoreValue || 10);
                
                // Create death effect
                this.particleSystem.createExplosion(enemy.position, enemy.type);
                this.audioManager.playSound('enemyDeath');
                
                continue;
            }
            
            if (enemy.reachedEnd) {
                // Enemy reached the end
                this.scene.remove(enemy.mesh);
                this.enemies.splice(i, 1);
                
                // Damage player
                this.playerHealthSystem.takeDamage(enemy.damage || 1);
                this.notificationManager.show('Enemy Reached Base!', 1500);
                this.audioManager.playSound('baseDamage');
                
                continue;
            }
            
            // Update enemy
            enemy.update(deltaTime, this.enemyPath);
        }
    }
    
    checkGameOver() {
        if (this.playerHealthSystem.isDead()) {
            this.gameOver();
        } else if (this.waveManager.isAllWavesComplete() && this.enemies.length === 0) {
            this.victory();
        }
    }
    
    gameOver() {
        this.gameState = 'gameOver';
        this.gameLoop.stop();
        
        // Show game over screen
        const gameOverScreen = document.getElementById('gameOverScreen');
        document.getElementById('finalScore').textContent = this.resourceManager.getScore();
        document.getElementById('wavesCompleted').textContent = this.waveManager.getCurrentWave() - 1;
        document.getElementById('enemiesDefeated').textContent = this.resourceManager.getEnemiesDefeated();
        
        gameOverScreen.style.display = 'flex';
        
        this.audioManager.stopBackgroundMusic();
        this.audioManager.playSound('gameOver');
    }
    
    victory() {
        this.gameState = 'victory';
        this.gameLoop.stop();
        
        this.notificationManager.show('VICTORY!', 5000);
        this.audioManager.playSound('victory');
        
        // TODO: Implement victory screen and level progression
        setTimeout(() => {
            this.nextLevel();
        }, 5000);
    }
    
    nextLevel() {
        this.currentLevel++;
        // TODO: Implement level progression
        this.notificationManager.show(`Level ${this.currentLevel}!`, 3000);
        this.restartGame();
    }
    
    render() {
        this.renderer.render(this.scene, this.camera);
    }
    
    // Public methods for other systems
    addEnemy(enemy) {
        this.enemies.push(enemy);
        this.scene.add(enemy.mesh);
    }
    
    addTower(tower) {
        this.towers.push(tower);
        this.scene.add(tower.mesh);
    }
    
    addProjectile(projectile) {
        this.projectiles.push(projectile);
        this.scene.add(projectile.mesh);
    }
    
    getEnemies() {
        return this.enemies;
    }
    
    getTowers() {
        return this.towers;
    }
    
    getProjectiles() {
        return this.projectiles;
    }
    
    getEnemyPath() {
        return this.enemyPath;
    }
    
    getScene() {
        return this.scene;
    }
    
    getCamera() {
        return this.camera;
    }
    
    getRenderer() {
        return this.renderer;
    }
}

// Global restart function
function restartGame() {
    location.reload();
}

// Initialize game when page loads
let game;
window.addEventListener('load', () => {
    game = new Game();
});

// Export for other modules
window.Game = Game;

