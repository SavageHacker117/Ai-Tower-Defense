// Map Data System
class MapData {
    constructor() {
        this.currentLevel = 1;
        this.mapWidth = 40;
        this.mapHeight = 30;
        
        // Map elements
        this.spawnPoint = { x: -18, z: -12 };
        this.endPoint = { x: 18, z: 12 };
        this.obstacles = [];
        this.decorations = [];
        this.specialAreas = [];
        
        // Pathfinding data
        this.navMesh = null;
        this.pathNodes = [];
        this.pathConnections = [];
        
        // Terrain data
        this.terrain = {
            type: 'grass',
            elevation: 0,
            texture: null
        };
        
        // Environmental settings
        this.environment = {
            skyColor: 0x87CEEB,
            fogColor: 0x87CEEB,
            fogDensity: 0.01,
            ambientLightColor: 0x404040,
            ambientLightIntensity: 0.4,
            directionalLightColor: 0xffffff,
            directionalLightIntensity: 0.8
        };
        
        // Map themes
        this.themes = {
            grassland: {
                skyColor: 0x87CEEB,
                terrainColor: 0x228B22,
                pathColor: 0x8B4513,
                obstacleColor: 0x654321
            },
            desert: {
                skyColor: 0xFFA500,
                terrainColor: 0xF4A460,
                pathColor: 0xD2691E,
                obstacleColor: 0x8B4513
            },
            winter: {
                skyColor: 0xB0C4DE,
                terrainColor: 0xF0F8FF,
                pathColor: 0x696969,
                obstacleColor: 0x2F4F4F
            },
            volcanic: {
                skyColor: 0x8B0000,
                terrainColor: 0x2F2F2F,
                pathColor: 0xFF4500,
                obstacleColor: 0x000000
            }
        };
        
        console.log('MapData initialized');
    }
    
    // Load level data
    async loadLevel(levelNumber) {
        this.currentLevel = levelNumber;
        
        try {
            // Generate map based on level
            this.generateMap(levelNumber);
            
            // Set theme based on level
            this.setTheme(this.getLevelTheme(levelNumber));
            
            console.log(`Map data loaded for level ${levelNumber}`);
            return true;
            
        } catch (error) {
            console.error('Failed to load map data:', error);
            return false;
        }
    }
    
    // Generate map procedurally
    generateMap(levelNumber) {
        // Clear existing data
        this.obstacles = [];
        this.decorations = [];
        this.specialAreas = [];
        this.pathNodes = [];
        
        // Generate based on level progression
        const difficulty = Math.min(levelNumber / 10, 1); // 0 to 1
        
        // Generate spawn and end points with some variation
        this.generateSpawnAndEndPoints(levelNumber);
        
        // Generate obstacles
        this.generateObstacles(levelNumber, difficulty);
        
        // Generate decorations
        this.generateDecorations(levelNumber);
        
        // Generate special areas
        this.generateSpecialAreas(levelNumber);
        
        // Generate navigation mesh
        this.generateNavMesh();
        
        console.log(`Generated map for level ${levelNumber} with ${this.obstacles.length} obstacles`);
    }
    
    generateSpawnAndEndPoints(levelNumber) {
        // Use Perlin noise or simple variation for spawn/end points
        const variation = (levelNumber * 0.1) % 1;
        const angle = variation * Math.PI * 2;
        
        // Spawn point (left side with variation)
        this.spawnPoint = {
            x: -18 + Math.cos(angle) * 2,
            z: -12 + Math.sin(angle) * 3
        };
        
        // End point (right side with variation)
        this.endPoint = {
            x: 18 + Math.cos(angle + Math.PI) * 2,
            z: 12 + Math.sin(angle + Math.PI) * 3
        };
    }
    
    generateObstacles(levelNumber, difficulty) {
        const baseObstacleCount = 5;
        const maxObstacleCount = 20;
        const obstacleCount = Math.floor(baseObstacleCount + difficulty * (maxObstacleCount - baseObstacleCount));
        
        for (let i = 0; i < obstacleCount; i++) {
            const obstacle = this.generateRandomObstacle(levelNumber);
            
            // Ensure obstacle doesn't block the main path
            if (this.isValidObstaclePosition(obstacle)) {
                this.obstacles.push(obstacle);
            }
        }
    }
    
    generateRandomObstacle(levelNumber) {
        const types = ['rock', 'tree', 'building', 'crystal', 'ruins'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        return {
            id: `obstacle_${Date.now()}_${Math.random()}`,
            type: type,
            position: {
                x: (Math.random() - 0.5) * this.mapWidth * 0.8,
                z: (Math.random() - 0.5) * this.mapHeight * 0.8
            },
            size: {
                width: 1 + Math.random() * 2,
                height: 1 + Math.random() * 3,
                depth: 1 + Math.random() * 2
            },
            rotation: Math.random() * Math.PI * 2,
            blocking: true
        };
    }
    
    generateDecorations(levelNumber) {
        const decorationCount = 10 + Math.floor(Math.random() * 15);
        
        for (let i = 0; i < decorationCount; i++) {
            const decoration = {
                id: `decoration_${Date.now()}_${Math.random()}`,
                type: this.getRandomDecorationType(levelNumber),
                position: {
                    x: (Math.random() - 0.5) * this.mapWidth,
                    z: (Math.random() - 0.5) * this.mapHeight
                },
                size: {
                    width: 0.5 + Math.random() * 1,
                    height: 0.5 + Math.random() * 2,
                    depth: 0.5 + Math.random() * 1
                },
                rotation: Math.random() * Math.PI * 2,
                blocking: false
            };
            
            this.decorations.push(decoration);
        }
    }
    
    generateSpecialAreas(levelNumber) {
        // Generate special areas like power-up zones, danger zones, etc.
        if (levelNumber > 3) {
            // Add power-up areas
            const powerUpArea = {
                id: `powerup_${levelNumber}`,
                type: 'powerup',
                position: {
                    x: (Math.random() - 0.5) * this.mapWidth * 0.6,
                    z: (Math.random() - 0.5) * this.mapHeight * 0.6
                },
                radius: 3,
                effect: 'damage_boost',
                duration: 30000 // 30 seconds
            };
            
            this.specialAreas.push(powerUpArea);
        }
        
        if (levelNumber > 5) {
            // Add danger zones
            const dangerArea = {
                id: `danger_${levelNumber}`,
                type: 'danger',
                position: {
                    x: (Math.random() - 0.5) * this.mapWidth * 0.4,
                    z: (Math.random() - 0.5) * this.mapHeight * 0.4
                },
                radius: 4,
                effect: 'slow_towers',
                intensity: 0.5
            };
            
            this.specialAreas.push(dangerArea);
        }
    }
    
    generateNavMesh() {
        // Create a simple grid-based navigation mesh
        const gridSize = 2; // 2x2 meter grid cells
        const gridWidth = Math.ceil(this.mapWidth / gridSize);
        const gridHeight = Math.ceil(this.mapHeight / gridSize);
        
        this.navMesh = [];
        
        for (let x = 0; x < gridWidth; x++) {
            this.navMesh[x] = [];
            for (let z = 0; z < gridHeight; z++) {
                const worldX = (x - gridWidth / 2) * gridSize;
                const worldZ = (z - gridHeight / 2) * gridSize;
                
                const isWalkable = this.isPositionWalkable(worldX, worldZ);
                
                this.navMesh[x][z] = {
                    x: x,
                    z: z,
                    worldX: worldX,
                    worldZ: worldZ,
                    walkable: isWalkable,
                    cost: isWalkable ? 1 : Infinity
                };
            }
        }
        
        // Generate path nodes for smoother pathfinding
        this.generatePathNodes();
    }
    
    generatePathNodes() {
        // Create key path nodes between spawn and end points
        const nodeCount = 8 + Math.floor(Math.random() * 4);
        this.pathNodes = [];
        
        // Always include spawn and end points
        this.pathNodes.push({
            id: 'spawn',
            position: { ...this.spawnPoint },
            connections: []
        });
        
        // Generate intermediate nodes
        for (let i = 1; i < nodeCount - 1; i++) {
            const progress = i / (nodeCount - 1);
            
            // Base position along straight line
            const baseX = this.spawnPoint.x + (this.endPoint.x - this.spawnPoint.x) * progress;
            const baseZ = this.spawnPoint.z + (this.endPoint.z - this.spawnPoint.z) * progress;
            
            // Add some randomness
            const offsetX = (Math.random() - 0.5) * 8;
            const offsetZ = (Math.random() - 0.5) * 6;
            
            const node = {
                id: `node_${i}`,
                position: {
                    x: baseX + offsetX,
                    z: baseZ + offsetZ
                },
                connections: []
            };
            
            // Ensure node is in walkable area
            if (this.isPositionWalkable(node.position.x, node.position.z)) {
                this.pathNodes.push(node);
            }
        }
        
        this.pathNodes.push({
            id: 'end',
            position: { ...this.endPoint },
            connections: []
        });
        
        // Connect nodes
        this.connectPathNodes();
    }
    
    connectPathNodes() {
        for (let i = 0; i < this.pathNodes.length - 1; i++) {
            const currentNode = this.pathNodes[i];
            const nextNode = this.pathNodes[i + 1];
            
            // Connect to next node
            currentNode.connections.push(nextNode.id);
            
            // Optionally connect to node after next for shortcuts
            if (i < this.pathNodes.length - 2 && Math.random() < 0.3) {
                const shortcutNode = this.pathNodes[i + 2];
                if (this.hasLineOfSight(currentNode.position, shortcutNode.position)) {
                    currentNode.connections.push(shortcutNode.id);
                }
            }
        }
    }
    
    // Validation methods
    isValidObstaclePosition(obstacle) {
        // Check if obstacle is too close to spawn or end points
        const minDistance = 4;
        
        const distanceToSpawn = this.getDistance(obstacle.position, this.spawnPoint);
        const distanceToEnd = this.getDistance(obstacle.position, this.endPoint);
        
        if (distanceToSpawn < minDistance || distanceToEnd < minDistance) {
            return false;
        }
        
        // Check if obstacle blocks the direct path
        if (this.intersectsDirectPath(obstacle)) {
            return false;
        }
        
        // Check if too close to other obstacles
        for (const existingObstacle of this.obstacles) {
            const distance = this.getDistance(obstacle.position, existingObstacle.position);
            if (distance < 3) {
                return false;
            }
        }
        
        return true;
    }
    
    isPositionWalkable(x, z) {
        // Check if position is within map bounds
        if (Math.abs(x) > this.mapWidth / 2 || Math.abs(z) > this.mapHeight / 2) {
            return false;
        }
        
        // Check if position intersects with obstacles
        for (const obstacle of this.obstacles) {
            if (obstacle.blocking) {
                const distance = this.getDistance({ x, z }, obstacle.position);
                const obstacleRadius = Math.max(obstacle.size.width, obstacle.size.depth) / 2;
                
                if (distance < obstacleRadius + 1) { // +1 for clearance
                    return false;
                }
            }
        }
        
        return true;
    }
    
    intersectsDirectPath(obstacle) {
        // Simple line-circle intersection test
        const lineStart = this.spawnPoint;
        const lineEnd = this.endPoint;
        const circleCenter = obstacle.position;
        const circleRadius = Math.max(obstacle.size.width, obstacle.size.depth) / 2;
        
        return this.lineCircleIntersection(lineStart, lineEnd, circleCenter, circleRadius);
    }
    
    hasLineOfSight(pos1, pos2) {
        // Check if there's a clear line of sight between two positions
        const steps = 20;
        
        for (let i = 0; i <= steps; i++) {
            const t = i / steps;
            const x = pos1.x + (pos2.x - pos1.x) * t;
            const z = pos1.z + (pos2.z - pos1.z) * t;
            
            if (!this.isPositionWalkable(x, z)) {
                return false;
            }
        }
        
        return true;
    }
    
    // Utility methods
    getDistance(pos1, pos2) {
        const dx = pos1.x - pos2.x;
        const dz = pos1.z - pos2.z;
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    lineCircleIntersection(lineStart, lineEnd, circleCenter, circleRadius) {
        // Vector from line start to circle center
        const dx = circleCenter.x - lineStart.x;
        const dz = circleCenter.z - lineStart.z;
        
        // Line direction vector
        const lineDx = lineEnd.x - lineStart.x;
        const lineDz = lineEnd.z - lineStart.z;
        const lineLength = Math.sqrt(lineDx * lineDx + lineDz * lineDz);
        
        if (lineLength === 0) return false;
        
        // Normalize line direction
        const lineUnitX = lineDx / lineLength;
        const lineUnitZ = lineDz / lineLength;
        
        // Project circle center onto line
        const projection = dx * lineUnitX + dz * lineUnitZ;
        const clampedProjection = Math.max(0, Math.min(lineLength, projection));
        
        // Closest point on line to circle center
        const closestX = lineStart.x + lineUnitX * clampedProjection;
        const closestZ = lineStart.z + lineUnitZ * clampedProjection;
        
        // Distance from circle center to closest point
        const distanceX = circleCenter.x - closestX;
        const distanceZ = circleCenter.z - closestZ;
        const distance = Math.sqrt(distanceX * distanceX + distanceZ * distanceZ);
        
        return distance <= circleRadius;
    }
    
    getRandomDecorationType(levelNumber) {
        const decorations = {
            grassland: ['flower', 'bush', 'small_rock', 'grass_patch'],
            desert: ['cactus', 'sand_dune', 'bone', 'dead_tree'],
            winter: ['snow_pile', 'ice_crystal', 'frozen_tree', 'snowman'],
            volcanic: ['lava_rock', 'steam_vent', 'ash_pile', 'crystal']
        };
        
        const theme = this.getLevelTheme(levelNumber);
        const themeDecorations = decorations[theme] || decorations.grassland;
        
        return themeDecorations[Math.floor(Math.random() * themeDecorations.length)];
    }
    
    getLevelTheme(levelNumber) {
        if (levelNumber <= 3) return 'grassland';
        if (levelNumber <= 6) return 'desert';
        if (levelNumber <= 9) return 'winter';
        return 'volcanic';
    }
    
    setTheme(themeName) {
        const theme = this.themes[themeName];
        if (theme) {
            this.environment.skyColor = theme.skyColor;
            this.terrain.color = theme.terrainColor;
        }
    }
    
    // Getters
    getSpawnPoint() {
        return { ...this.spawnPoint };
    }
    
    getEndPoint() {
        return { ...this.endPoint };
    }
    
    getObstacles() {
        return [...this.obstacles];
    }
    
    getDecorations() {
        return [...this.decorations];
    }
    
    getSpecialAreas() {
        return [...this.specialAreas];
    }
    
    getNavMesh() {
        return this.navMesh;
    }
    
    getPathNodes() {
        return [...this.pathNodes];
    }
    
    getEnvironmentSettings() {
        return { ...this.environment };
    }
    
    getMapBounds() {
        return {
            width: this.mapWidth,
            height: this.mapHeight,
            minX: -this.mapWidth / 2,
            maxX: this.mapWidth / 2,
            minZ: -this.mapHeight / 2,
            maxZ: this.mapHeight / 2
        };
    }
    
    // Position queries
    isInBounds(x, z) {
        return Math.abs(x) <= this.mapWidth / 2 && Math.abs(z) <= this.mapHeight / 2;
    }
    
    getTerrainHeight(x, z) {
        // Simple flat terrain for now
        return this.terrain.elevation;
    }
    
    getNearestWalkablePosition(x, z) {
        if (this.isPositionWalkable(x, z)) {
            return { x, z };
        }
        
        // Search in expanding circles
        for (let radius = 1; radius <= 10; radius++) {
            const steps = radius * 8;
            for (let i = 0; i < steps; i++) {
                const angle = (i / steps) * Math.PI * 2;
                const testX = x + Math.cos(angle) * radius;
                const testZ = z + Math.sin(angle) * radius;
                
                if (this.isPositionWalkable(testX, testZ)) {
                    return { x: testX, z: testZ };
                }
            }
        }
        
        // Fallback to spawn point
        return this.getSpawnPoint();
    }
    
    // Save/Load
    saveMapData() {
        return {
            currentLevel: this.currentLevel,
            spawnPoint: this.spawnPoint,
            endPoint: this.endPoint,
            obstacles: this.obstacles,
            decorations: this.decorations,
            specialAreas: this.specialAreas,
            pathNodes: this.pathNodes,
            environment: this.environment
        };
    }
    
    loadMapData(data) {
        if (data.currentLevel !== undefined) this.currentLevel = data.currentLevel;
        if (data.spawnPoint) this.spawnPoint = data.spawnPoint;
        if (data.endPoint) this.endPoint = data.endPoint;
        if (data.obstacles) this.obstacles = data.obstacles;
        if (data.decorations) this.decorations = data.decorations;
        if (data.specialAreas) this.specialAreas = data.specialAreas;
        if (data.pathNodes) this.pathNodes = data.pathNodes;
        if (data.environment) this.environment = data.environment;
        
        // Regenerate nav mesh
        this.generateNavMesh();
    }
}

// Export for use in other modules
window.MapData = MapData;

