// Game Loop System
class GameLoop {
    constructor(game) {
        this.game = game;
        this.isRunning = false;
        this.lastTime = 0;
        this.deltaTime = 0;
        this.targetFPS = 60;
        this.frameTime = 1000 / this.targetFPS;
        this.accumulator = 0;
        
        // Performance monitoring
        this.fpsCounter = 0;
        this.fpsTimer = 0;
        this.currentFPS = 0;
        
        // Animation frame request ID
        this.animationFrameId = null;
        
        // Bind the loop function
        this.loop = this.loop.bind(this);
    }
    
    start() {
        if (this.isRunning) return;
        
        this.isRunning = true;
        this.lastTime = performance.now();
        this.animationFrameId = requestAnimationFrame(this.loop);
        
        console.log('Game loop started');
    }
    
    stop() {
        if (!this.isRunning) return;
        
        this.isRunning = false;
        
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
        
        console.log('Game loop stopped');
    }
    
    loop(currentTime) {
        if (!this.isRunning) return;
        
        // Calculate delta time
        this.deltaTime = currentTime - this.lastTime;
        this.lastTime = currentTime;
        
        // Cap delta time to prevent spiral of death
        if (this.deltaTime > 100) {
            this.deltaTime = 100;
        }
        
        // Update FPS counter
        this.updateFPS(this.deltaTime);
        
        // Fixed timestep update with accumulator
        this.accumulator += this.deltaTime;
        
        while (this.accumulator >= this.frameTime) {
            // Update game logic at fixed timestep
            this.update(this.frameTime / 1000); // Convert to seconds
            this.accumulator -= this.frameTime;
        }
        
        // Render at display refresh rate
        this.render();
        
        // Schedule next frame
        this.animationFrameId = requestAnimationFrame(this.loop);
    }
    
    update(deltaTime) {
        try {
            // Update the main game
            this.game.update(deltaTime);
            
        } catch (error) {
            console.error('Error in game update:', error);
            this.handleError(error);
        }
    }
    
    render() {
        try {
            // Render the game
            this.game.render();
            
        } catch (error) {
            console.error('Error in game render:', error);
            this.handleError(error);
        }
    }
    
    updateFPS(deltaTime) {
        this.fpsCounter++;
        this.fpsTimer += deltaTime;
        
        if (this.fpsTimer >= 1000) { // Update every second
            this.currentFPS = Math.round(this.fpsCounter * 1000 / this.fpsTimer);
            this.fpsCounter = 0;
            this.fpsTimer = 0;
            
            // Update FPS display if element exists
            const fpsElement = document.getElementById('fps');
            if (fpsElement) {
                fpsElement.textContent = this.currentFPS;
            }
            
            // Performance warning
            if (this.currentFPS < 30) {
                console.warn(`Low FPS detected: ${this.currentFPS}`);
            }
        }
    }
    
    handleError(error) {
        console.error('Critical error in game loop:', error);
        this.stop();
        
        // Show error to user
        if (this.game && this.game.notificationManager) {
            this.game.notificationManager.show('Game Error: Please refresh', 5000);
        }
    }
    
    // Getters
    getCurrentFPS() {
        return this.currentFPS;
    }
    
    getDeltaTime() {
        return this.deltaTime;
    }
    
    isGameRunning() {
        return this.isRunning;
    }
    
    // Pause/Resume functionality
    pause() {
        if (this.isRunning) {
            this.stop();
        }
    }
    
    resume() {
        if (!this.isRunning) {
            this.start();
        }
    }
    
    // Performance optimization methods
    setTargetFPS(fps) {
        this.targetFPS = Math.max(30, Math.min(120, fps)); // Clamp between 30-120
        this.frameTime = 1000 / this.targetFPS;
        console.log(`Target FPS set to: ${this.targetFPS}`);
    }
    
    // Debug information
    getDebugInfo() {
        return {
            isRunning: this.isRunning,
            currentFPS: this.currentFPS,
            targetFPS: this.targetFPS,
            deltaTime: this.deltaTime,
            accumulator: this.accumulator
        };
    }
}

// Export for use in other modules
window.GameLoop = GameLoop;

