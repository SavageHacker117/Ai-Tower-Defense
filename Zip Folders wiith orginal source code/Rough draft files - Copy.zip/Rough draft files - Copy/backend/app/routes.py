from flask import jsonify, request, current_app
from . import db
from .models import Player, GameState
import jwt
import datetime

@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400
    if Player.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already exists'}), 400
    new_player = Player(username=username)
    new_player.set_password(password)
    db.session.add(new_player)
    db.session.commit()
    return jsonify({'message': 'Player registered successfully'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    player = Player.query.filter_by(username=username).first()
    if player and player.check_password(password):
        token = jwt.encode({
            'player_id': player.id,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, current_app.config['SECRET_KEY'], algorithm="HS256")
        return jsonify({'token': token}), 200
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/save', methods=['POST'])
def save_game_state():
    data = request.get_json()
    player_id = data.get('player_id')
    if not player_id:
        return jsonify({'error': 'Player ID is required'}), 400
    player = Player.query.get(player_id)
    if not player:
        return jsonify({'error': 'Player not found'}), 404
    game_state = player.game_state
    if not game_state:
        game_state = GameState(player_id=player_id)
    game_state.wave_number = data.get('wave_number', game_state.wave_number)
    game_state.resources = data.get('resources', game_state.resources)
    game_state.player_lives = data.get('player_lives', game_state.player_lives)
    game_state.towers_data = data.get('towers_data', game_state.towers_data)
    db.session.add(game_state)
    db.session.commit()
    return jsonify({'message': f'Game saved for player {player_id}'}), 200

@app.route('/api/load/<int:player_id>', methods=['GET'])
def load_game_state(player_id):
    player = Player.query.get(player_id)
    if not player:
        return jsonify({'error': 'Player not found'}), 404
    game_state = player.game_state
    if not game_state:
        return jsonify({'error': 'No saved game found for this player'}), 404
    return jsonify(game_state.to_dict()), 200